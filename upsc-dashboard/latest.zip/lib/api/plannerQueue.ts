// upsc-dashboard/lib/api/plannerQueue.ts
const PLANNER_VAULT_KEY = "upsc_planner_offline_vault";
const DELTA_QUEUE_KEY = "upsc_planner_delta_queue";
const API_URL = "http://localhost:5000/api"; // Adjust if your backend URL is different

// 🛡️ ENGINE 1: FULL PLAN SAVE (For major structural changes like Matrix Generation)
export async function savePlannerSafely(plan: any) {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(PLANNER_VAULT_KEY, JSON.stringify(plan));
    } catch (storageErr) {
      console.error("🚨 Critical: Local storage full. Cannot vault plan.", storageErr);
    }
  }

  try {
    const res = await fetch(`${API_URL}/planner`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(plan),
    });

    if (res.ok && typeof window !== "undefined") {
      window.localStorage.removeItem(PLANNER_VAULT_KEY);
    }
  } catch (err) {
    console.warn("⚠️ Network offline. Full Plan secured in Browser Vault.");
  }
}

// 🛡️ ENGINE 2: THE DELTA PATCH (For ticking checkboxes without network bloat)
export async function patchMissionSafely(dayIndex: number, missionId: string, updates: any) {
  const deltaPayload = {
    timestamp: Date.now(),
    dayIndex,
    missionId,
    updates,
  };

  try {
    const res = await fetch(`${API_URL}/planner/patch`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(deltaPayload),
    });

    if (!res.ok) throw new Error("Network Patch Failed");
  } catch (err) {
    console.warn("⚠️ Offline. Attempting to secure Delta Patch in local queue.");
    if (typeof window !== "undefined") {
      try {
        const existingQueue = JSON.parse(window.localStorage.getItem(DELTA_QUEUE_KEY) || "[]");
        existingQueue.push(deltaPayload);
        window.localStorage.setItem(DELTA_QUEUE_KEY, JSON.stringify(existingQueue));
      } catch (storageErr) {
        // ✅ Graceful degradation: Prevent the app from crashing if storage is full
        console.error("🚨 Critical: Local storage full. Cannot queue offline patch.", storageErr);
        alert("Local storage is full. Please reconnect to the internet to sync your progress.");
      }
    }
  }
}

// 🛡️ ENGINE 3: THE VAULT FLUSHER (Re-syncs everything when internet returns)
export async function flushPlannerVault() {
  if (typeof window === "undefined") return;

  // 1. Flush Full Plans
  const vaultedPlan = window.localStorage.getItem(PLANNER_VAULT_KEY);
  if (vaultedPlan) {
    try {
      const res = await fetch(`${API_URL}/planner`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: vaultedPlan,
      });
      if (res.ok) window.localStorage.removeItem(PLANNER_VAULT_KEY);
    } catch (err) {
      console.warn("Full plan vault flush failed.");
    }
  }

  // 2. Flush Delta Queue
  const deltaQueue = JSON.parse(window.localStorage.getItem(DELTA_QUEUE_KEY) || "[]");
  if (deltaQueue.length > 0) {
    console.log(`🌐 Flushing ${deltaQueue.length} microscopic patches to DB...`);
    // ✅ Extract the exact timestamps we are attempting to sync
    const inFlightTimestamps = new Set(deltaQueue.map((p: any) => p.timestamp));

    try {
      const res = await fetch(`${API_URL}/planner/patch-batch`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ patches: deltaQueue }),
      });

      if (res.ok) {
        // ✅ Safely filter out ONLY the patches that successfully synced
        // This ensures patches added while this request was in flight are not deleted
        const currentQueue = JSON.parse(window.localStorage.getItem(DELTA_QUEUE_KEY) || "[]");
        const remainingQueue = currentQueue.filter(
          (p: any) => !inFlightTimestamps.has(p.timestamp)
        );

        if (remainingQueue.length > 0) {
          window.localStorage.setItem(DELTA_QUEUE_KEY, JSON.stringify(remainingQueue));
        } else {
          window.localStorage.removeItem(DELTA_QUEUE_KEY);
        }
      }
    } catch (err) {
      console.warn("Batch delta flush failed.");
    }
  }
}