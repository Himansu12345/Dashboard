import type { RawSubjectNode } from "../types";

export const RAW_D = [
  // =========================== CHAPTER I ===========================
  {
    "id": "I",
    "p": "pm",
    "label": "Indian Architecture (Indus to Modern)",
    "children": [
      {
        "p": "pm2",
        "label": "Indus Valley to Mauryan",
        "children": [
          {
            "label": "Indus Valley Architecture (2600‑1900 BC)",
            "children": [
              { "label": "Urban planning: grid pattern, burnt bricks (4:2:1 ratio), advanced drainage, Great Bath (Mohenjodaro), granaries, dockyard (Lothal)." },
              { "label": "No temples or palaces found; utilitarian and civic structures dominant." },
              { "label": "MAINS: Town planning reflects sophisticated municipal governance and emphasis on hygiene." }
            ]
          },
          {
            "label": "Mauryan Architecture (322‑185 BC)",
            "children": [
              { "label": "Pillars: monolithic, highly polished (Mauryan polish), animal capitals (Lion capital at Sarnath – national emblem, Bull at Rampurva)." },
              { "label": "Stupas: Sanchi Stupa (built by Ashoka, enlarged later); wooden railings replaced by stone under Shungas." },
              { "label": "Rock‑cut caves: Barabar Caves (Bihar) – earliest surviving rock‑cut caves, donated to Ajivikas; Lomash Rishi cave (façade with horseshoe arch)." },
              { "label": "Palace: Palaces at Pataliputra (wooden); described by Megasthenes." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Stupas & Rock‑Cut Caves (Post‑Mauryan to Medieval)",
        "children": [
          {
            "label": "Stupa Architecture",
            "children": [
              { "label": "Key elements: Anda (dome), Harmika (square railing top), Chattra (umbrella), Medhi (circular base), Torana (gateways), Vedika (railing)." },
              { "label": "Sanchi Stupa: 3 stupas; Stupa 1 has 4 richly carved Toranas with Jataka scenes.\nStupa 2 houses relics of Buddhist monks." },
              { "label": "Amaravati Stupa (Andhra): Marble, detailed narrative art; Nagarjunakonda.\nBharhut Stupa (MP): earliest surviving torana." },
              { "label": "MAINS: Stupas evolved from simple burial mounds to elaborate symbolic structures representing the Buddha's parinirvana and cosmic body." }
            ]
          },
          {
            "label": "Rock‑Cut Caves (Chronological overview)",
            "children": [
              { "label": "Ajanta Caves (Maharashtra, 2nd BC–6th AD): Buddhist, chaityas & viharas; exquisite frescoes depicting Jataka tales; earlier caves (Hinayana) lack Buddha images; later (Mahayana) have them." },
              { "label": "Ellora Caves (Maharashtra, 6th–11th AD): 34 caves – Buddhist (1‑12), Hindu (13‑29), Jain (30‑34).\nKailasanatha Temple (Cave 16) – largest monolithic rock‑cut temple built by Rashtrakuta Krishna I." },
              { "label": "Elephanta Caves (Maharashtra): Shiva‑focused; Trimurti (three‑faced) Shiva panel; Portuguese inflicted damage." },
              { "label": "Baghavati/Badami Caves (Karnataka): Chalukyas; Hindu, Jain." },
              { "label": "Udayagiri & Khandagiri (Odisha): Jain caves under Kharavela; Hathigumpha inscription." },
              { "label": "TRAP: Ajanta is exclusively Buddhist; Ellora is multi‑religious." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Temple Architecture – Nagara, Dravida, Vesara (Comprehensive)",
        "children": [
          {
            "label": "Nagara (North Indian) – Sub‑styles & Examples",
            "children": [
              { "label": "Basic: Shikhara (curvilinear tower), Garbhagriha (sanctum), Mandapa (hall).\nNo tank, smaller gopurams.\nPanchayatana arrangement common." },
              { "label": "Odisha / Kalinga School: Lingaraja Temple (Bhubaneswar), Sun Temple (Konark – chariot with 24 wheels), Jagannath Temple (Puri)." },
              { "label": "Khajuraho School (Chandela): Lakshmana, Kandariya Mahadeva, Vishvanatha temples; erotic sculptures, perfect balance of sculptures and architecture." },
              { "label": "Solanki / Maru‑Gurjara: Dilwara Jain temples (Mount Abu, marble), Modhera Sun Temple (Gujarat)." }
            ]
          },
          {
            "label": "Dravida (South Indian) – Sub‑styles & Examples",
            "children": [
              { "label": "Basic: Vimana (pyramidal tower) over sanctum, Gopurams (gateways), tank, pillared halls.\nThe temple is a fortress complex." },
              { "label": "Pallava: Shore Temple (Mahabalipuram), Kailasanatha (Kanchi).\nPancha Rathas (Mahabalipuram) – monolithic." },
              { "label": "Chola: Brihadeshwara Temple (Thanjavur – Rajaraja I), Gangaikondacholapuram (Rajendra I), Airavateshwar (Darasuram).\nGrand vimanas, extensive sculptures." },
              { "label": "Vijayanagara: Virupaksha, Vitthala Temple (Hampi – musical pillars, stone chariot).\nLarge gopurams, Kalyanamandapa (marriage hall)." },
              { "label": "Nayaka / Madurai: Meenakshi Temple (Madurai) – massive gopurams, thousand‑pillared halls." },
              { "label": "Pala & Sena (Bengal): Terracotta temples; distinctive curved roof (char‑chala).\nBishnupur temples." }
            ]
          },
          {
            "label": "Vesara (Hybrid – Deccan)",
            "children": [
              { "label": "Blend of Nagara and Dravida.\nStar‑shaped platforms, soft soapstone, intricate filigree work." },
              { "label": "Chalukyas of Badami: Aihole (Lad Khan, Durga Temple), Pattadakal (Virupaksha, Mallikarjuna)." },
              { "label": "Hoysalas: Belur (Chennakesava), Halebid (Hoysalesvara).\nStar‑shaped platforms, ornate lintels." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Indo‑Islamic Architecture (Sultanate & Mughal)",
        "children": [
          {
            "label": "Delhi Sultanate (1206‑1526)",
            "children": [
              { "label": "Slave/Qutb‑ud‑din Aibak: Qutb Minar (partially), Quwwat‑ul‑Islam mosque, Adhai din ka Jhonpra." },
              { "label": "Khilji: Alai Darwaza – use of true arch and dome, red sandstone with white marble inlay." },
              { "label": "Tughlaq: Tughlaqabad fort, sloping walls, cheap grey stone; Firoz Shah Tughlaq – Kotla, Firozabad." },
              { "label": "Lodhi: octagonal tombs, double dome technique (Sikandar Lodi's tomb); gardens." },
              { "label": "Regional Sultanates: Gujarat (Jama Masjid, Champaner), Malwa (Jahaz Mahal, Mandu), Bengal (Adina Masjid, Pandua), Deccan (Gol Gumbaz, Bijapur – whispering gallery)." }
            ]
          },
          {
            "label": "Mughal Architecture (1526‑1707)",
            "children": [
              { "label": "Babur: Bagh‑e‑Babishta, mosque at Ayodhya (Babri)." },
              { "label": "Humayun: Purana Qila (Din‑Panah); Humayun's Tomb (Akbar‑built, first garden tomb, precursor to Taj)." },
              { "label": "Akbar: Agra Fort, Fatehpur Sikri (Buland Darwaza, Panch Mahal, Jodha Bai's palace, Ibadat Khana), Diwan‑i‑Am, Diwan‑i‑Khas (pillar with cosmological symbols).\nUsed red sandstone with white marble inlay." },
              { "label": "Jahangir: emphasis on gardens (Shalimar Bagh, Nishat Bagh), miniature painting flourished.\nTomb of Itimad‑ud‑Daula (Pietra Dura pioneer)." },
              { "label": "Shah Jahan (Climax): Taj Mahal (Agra, white marble, Ustad Ahmad Lahauri), Red Fort (Delhi), Jama Masjid, Moti Masjid.\nExtensive use of Pietra Dura, cusped arches, dome with inverted lotus." },
              { "label": "Aurangzeb: Bibi Ka Maqbara (Aurangabad, poor Taj replica).\nDecline of patronage." },
              { "label": "MAINS: Mughal architecture synthesised Persian, Timurid, and indigenous Indian elements, reflecting imperial ideology and courtly culture." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Colonial & Modern Architecture",
        "children": [
          {
            "label": "British Colonial Styles",
            "children": [
              { "label": "Neo‑Classical: Town Hall (Bombay), St.\nPaul's Cathedral (Calcutta)." },
              { "label": "Neo‑Gothic: Victoria Terminus (Chhatrapati Shivaji Terminus, Bombay – F.W.\nStevens), St.\nMary's, High Court Bombay." },
              { "label": "Indo‑Saracenic: Gateway of India (Bombay), Victoria Memorial (Calcutta), Mysore Palace, New Delhi's Parliament, Rashtrapati Bhavan (Edwin Lutyens & Herbert Baker, blend of classical, Buddhist, Mughal elements)." }
            ]
          },
          {
            "label": "Post‑Independence",
            "children": [
              { "label": "Chandigarh: designed by Le Corbusier (Capitol Complex – High Court, Secretariat, Assembly).\nGandhinagar (H.K.\nMewada)." },
              { "label": "Auroville (Matrimandir), IIT Kanpur (Padmanabha), etc.\nNational War Memorial, Statue of Unity (Sardar Patel)." },
              { "label": "Modern movements: revivalism, critical regionalism, green architecture." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER II ===========================
  {
    "id": "II",
    "p": "pm",
    "label": "Indian Sculpture (Maurya to Vijayanagara)",
    "children": [
      {
        "p": "pm2",
        "label": "Mauryan to Gupta",
        "children": [
          {
            "label": "Mauryan & Shunga",
            "children": [
              { "label": "Lion Capital (Sarnath) – 4 lions, Dharmachakra (24 spokes), animals (bull, horse, elephant, lion).\nPolished sandstone." },
              { "label": "Didarganj Yakshini – highly polished, life‑size; male deities (Yaksha)." },
              { "label": "Bharhut railings – narrative Jataka panels, red sandstone.\nSanchi Toranas – symbolic Buddha (footprints, empty throne, Bodhi tree)." }
            ]
          },
          {
            "label": "Post‑Mauryan Schools (Gandhara, Mathura, Amaravati)",
            "children": [
              { "label": "Gandhara: Greco‑Roman influence; blue‑grey schist, realistic, wavy hair, moustache, muscular Buddha in Roman toga; standing figure with Abhaya mudra; Kushan patronage." },
              { "label": "Mathura: Red sandstone, indigenous, plump smiling Buddha, seated in Padmasana, broad shoulders; also Hindu (Vishnu, Shiva) and Jain images; first human image of Buddha appeared roughly simultaneously with Gandhara." },
              { "label": "Amaravati: White marble, slender dynamic figures, complex narrative reliefs of Jataka stories; Satavahana/Ikshvaku period." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Gupta to Chola (Classical Phase)",
        "children": [
          {
            "label": "Gupta Sculpture",
            "children": [
              { "label": "Sarnath School: Polished sandstone, graceful, serene, transparent drapery clinging to body (wet drapery), standing Buddha with halo.\nMathura Gupta style: softer, more stylized." },
              { "label": "Important images: Sarnath Buddha (National Museum), Varaha avatar (Udayagiri Caves), Dashavatara Temple (Deogarh)." }
            ]
          },
          {
            "label": "Chola & Vijayanagara Bronzes",
            "children": [
              { "label": "Chola Bronzes: Lost wax (Cire‑Perdue) technique; copper alloy with high tin content.\nNataraja (Dancing Shiva) – four hands, damru (creation), fire (destruction), Abhaya mudra, foot on dwarf (Apasmara).\nOther: Sivakami, Kali, Tiruvalluvar." },
              { "label": "Vijayanagara: large stone monolithic sculptures (Gomateshwara at Sravanabelagola is earlier Hoysala, not Vijayanagara); Vijayanagara produced excellent bronzes and temple sculptures like Narasimha, Ganesha." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER III ===========================
  {
    "id": "III",
    "p": "pm",
    "label": "Indian Painting (Mural & Miniature)",
    "children": [
      {
        "p": "pm2",
        "label": "Mural Painting Traditions",
        "children": [
          {
            "label": "Ajanta Murals (Maharashtra, 2nd BC‑6th AD)",
            "children": [
              { "label": "Buddhist themes, Jataka stories, painted on dry plaster, tempera technique (pigment + gum/resin)." },
              { "label": "Key frescoes: Bodhisattva Padmapani (Avalokiteshvara), Vajrapani, Mahajanaka Jataka.\nUse of natural colours, graceful lines, shading (Vartana), perspective.\nBoth Hinayana (early) and Mahayana (later) phases." }
            ]
          },
          {
            "label": "Other Mural Schools",
            "children": [
              { "label": "Ellora Murals (5th‑9th AD): Hindu themes (Shiva, Vishnu).\nBagh Caves (MP): Buddhist, similar style to Ajanta but more earthly." },
              { "label": "Sittanavasal (Tamil Nadu): Jain murals (Pandya period, 7th AD), lotus pond, dancing figures." },
              { "label": "Lepakshi (Andhra Pradesh, Vijayanagara): murals on temple ceilings, linear style." },
              { "label": "Kerala Murals: bold colours, large eyes, traditional themes (Padmanabhapuram, Mattancherry)." },
              { "label": "Bundi/Chittorgarh: miniature‑style murals within palaces.\nWarli and other tribal/folk murals." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Miniature Painting (Mughal, Rajput, Pahari, Deccan)",
        "children": [
          {
            "label": "Mughal Miniature (16th‑19th century)",
            "children": [
              { "label": "Beginning: Humayun brought Persian artists (Mir Sayyid Ali, Abdus Samad).\nAkbar established imperial karkhana (workshop); illustrated Hamzanama (Dastan‑e‑Amir Hamza) – 1200 large paintings." },
              { "label": "Akbar: naturalistic, action scenes, European naturalism via Portuguese/Jesuit influence; Tutinama (Tales of a Parrot), Akbarnama." },
              { "label": "Jahangir (Peak): natural history, birds/animals (Mansur's Siberian Crane, Zebra), portraits, allegorical paintings; 'Allegory of the Darbar of Jahangir'." },
              { "label": "Shah Jahan: romantic, court scenes; graceful figures.\nAurangzeb discouraged, painters migrated to regional courts." },
              { "label": "Technique: Wasli (paper), intricate brushwork, pure colors, gold and lapis lazuli." }
            ]
          },
          {
            "label": "Rajput (Rajasthani) Miniature",
            "children": [
              { "label": "Schools: Mewar (bold, bright, folkish), Bundi (landscape, love), Kota (hunting, Durbar), Kishangarh (Bani Thani – Mona Lisa of India, under Raja Sawant Singh), Jaipur (court scenes), Bikaner (refined Mughal influence), Marwar." },
              { "label": "Themes: Krishna Leela, Ragamala (musical modes), Baramasa (12 months), Nayaka‑Nayika Bheda (hero‑heroine classification)." }
            ]
          },
          {
            "label": "Pahari (Hill) Painting",
            "children": [
              { "label": "Schools: Basohli (bold, bright, stylized), Guler‑Kangra (soft, lyrical, idealised female beauty – came under Raja Sansar Chand of Kangra), Kullu, Garhwal." },
              { "label": "Themes: Bhagavata Purana, Geet Govinda, Rasamanjari (love poetry), Krishna‑Radha legends." }
            ]
          },
          {
            "label": "Deccan Miniature",
            "children": [
              { "label": "Ahmednagar, Golconda, Bijapur: rich colours, elongated figures, Persian influence, sensuous; Bijapur – 'Yogini', 'Lady with Myna'." }
            ]
          },
          {
            "label": "Tanjore/Thanjavur Painting (Maratha period)",
            "children": [
              { "label": "South Indian style, gold leaf, bright colours, embedded gems, deities (Krishna, Shiva), known for gesso work." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Folk Paintings of India (Statewise)",
        "children": [
          { "label": "Madhubani (Bihar): geometric, natural dyes, rituals, Ram‑Sita, done by women.\nPatachitra (Odisha): cloth scrolls, Jagannath.\nPithora (Gujarat/MP): Rathwa tribe." },
          { "label": "Warli (Maharashtra): triangles, circles, stick figures, daily life.\nGond (MP): vibrant, dots and dashes, flora‑fauna.\nPhad (Rajasthan): scroll paintings of Pabuji and Devnarayan." },
          { "label": "Kalamkari (Andhra): vegetable dyes, pen (kalam) work; Srikalahasti (freehand) and Machilipatnam (block‑print).\nKalighat (West Bengal): watercolour, social satire." },
          { "label": "Cheriyal Scrolls (Telangana): Nakashi art.\nManjusha (Bihar).\nThanka (Sikkim/Himalayan Buddhist)." }
        ]
      }
    ]
  },
  // =========================== CHAPTER IV ===========================
  {
    "id": "IV",
    "p": "pm3",
    "label": "Classical & Folk Dances of India",
    "children": [
      {
        "p": "pm3",
        "label": "8 Classical Dances (Sangeet Natak Akademi) – Key Details",
        "children": [
          {
            "label": "Bharatanatyam (Tamil Nadu)",
            "children": [
              { "label": "Oldest classical dance, derived from Natya Shastra and temple dancers (Devadasis).\nCodified by Rukmini Devi Arundale." },
              { "label": "Elements: Nritta (pure dance), Nritya (expressive), Natya (drama).\nFixed torso, bent legs, intricate footwork, hand gestures (hastas).\nAccompaniment: Carnatic music." },
              { "label": "Famous exponents: Rukmini Devi, Bala Saraswati, Alarmel Valli, Padma Subrahmanyam." }
            ]
          },
          {
            "label": "Kathak (North India)",
            "children": [
              { "label": "Originates from Katha (storytelling); influenced by Bhakti (Vaishnavism) and later Mughal courts (Lucknow, Jaipur, Banaras gharanas)." },
              { "label": "Rapid spins (chakkars), rhythmic footwork (tatkar), expressive gesture (abhinaya).\nWears ghunghroos." },
              { "label": "Prominent: Birju Maharaj, Sitara Devi, Shovana Narayan.\nInstruments: Tabla, Sarangi, Pakhawaj." }
            ]
          },
          {
            "label": "Kathakali (Kerala)",
            "children": [
              { "label": "Classical dance‑drama; all‑male initially, epic themes (Ramayana, Mahabharata).\nElaborate makeup (Aharya), massive headgear, colourful face painting (green for hero, red for villain)." },
              { "label": "Hand gestures and facial expressions prominent; accompanied by percussion (Chenda, Maddalam) and vocal." },
              { "label": "Exponents: Vellinezhi, Kalamandalam Gopi." }
            ]
          },
          {
            "label": "Kuchipudi (Andhra Pradesh)",
            "children": [
              { "label": "Originated in Kuchipudi village by Siddhendra Yogi.\nDance‑drama with dialogue; typical Tarangam (dancing on brass plate)." },
              { "label": "Exponents: Vempati Chinna Satyam, Raja & Radha Reddy, Yamini Krishnamurthy." }
            ]
          },
          {
            "label": "Manipuri (Manipur)",
            "children": [
              { "label": "Soft, lyrical, devotional (Vaishnavism, Radha‑Krishna).\nDistinct costume: barrel‑shaped skirt (Potloi) for women.\nAvoids aggressive movements." },
              { "label": "Ras Leela, Lai Haraoba.\nExponents: Guru Bipin Singh, Darshana Jhaveri." }
            ]
          },
          {
            "label": "Odissi (Odisha)",
            "children": [
              { "label": "From Odisha temples (Mahari dancers), later revived by Kelucharan Mohapatra.\nTribhanga posture (three bends)." },
              { "label": "Compositions from Geet Govinda.\nSculpturesque poses.\nPakhawaj accompaniment.\nExponents: Sonal Mansingh, Sanjukta Panigrahi." }
            ]
          },
          {
            "label": "Mohiniyattam (Kerala)",
            "children": [
              { "label": "Solo female dance, gentle, swaying (lasya), reminiscent of the enchantress Mohini.\nWhite/gold costume, hair in bun." },
              { "label": "Exponents: Kalamandalam Kshemavathy, Sunanda Nair." }
            ]
          },
          {
            "label": "Sattriya (Assam)",
            "children": [
              { "label": "From Sattras (Vaishnavite monasteries) of Assam, introduced by Sankaradeva (15th‑16th AD).\nDevotional, dance‑drama.\nGranted classical status in 2000." },
              { "label": "Exponents: Indira PP Bora, Sharodi Saikia." }
            ]
          },
          {
            "label": "Chhau (Eastern India)",
            "children": [
              { "label": "Semi‑classical martial dance; three styles: Seraikela (Jharkhand), Purulia (WB), Mayurbhanj (Odisha).\nMasked (except Mayurbhanj).\nDepicts epic themes.\nInscribed on UNESCO ICH list." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Folk Dances (Statewise high‑yield list)",
        "children": [
          { "label": "Andhra: Kuchipudi (classical), Kolattam, Lambadi.\nArunachal: Bardo Chham, Ponung.\nAssam: Bihu (Rongali Bihu), Bagurumba.\nBihar: Jat‑Jatin, Jhijhian.\nChhattisgarh: Panthi, Raut Nacha.\nGoa: Dhalo, Ghode Modni." },
          { "label": "Gujarat: Garba (UNESCO ICH), Dandiya, Tippani.\nHaryana: Phag, Khoria.\nHimachal: Nati, Kullu Nati.\nJ&K: Rouf, Dumhal.\nJharkhand: Chhau, Karma.\nKarnataka: Yakshagana (dance‑drama), Dollu Kunitha.\nKerala: Theyyam, Ottamthullal, Margamkali." },
          { "label": "Maharashtra: Lavni, Tamasha.\nManipur: Manipuri (classical), Thang‑Ta.\nMeghalaya: Laho, Shad Suk Mynsiem.\nMizoram: Cheraw (bamboo dance).\nNagaland: Chang Lo, Naga warrior dance.\nOdisha: Gotipua, Ghumura.\nPunjab: Bhangra, Giddha.\nRajasthan: Ghoomar, Kalbelia (UNESCO ICH).\nSikkim: Singhi Chham." },
          { "label": "Tamil Nadu: Karakattam, Oyilattam.\nTelangana: Perini Shivatandavam.\nTripura: Hojagiri.\nUP: Raslila, Charkula.\nUttarakhand: Chholiya, Garhwali.\nWest Bengal: Chhau, Gambhira." }
        ]
      }
    ]
  },
  // =========================== CHAPTER V ===========================
  {
    "id": "V",
    "p": "pm2",
    "label": "Indian Music (Hindustani, Carnatic & Folk Instruments)",
    "children": [
      {
        "p": "pm2",
        "label": "Hindustani Classical Music",
        "children": [
          {
            "label": "Basic Concepts",
            "children": [
              { "label": "Raga (melodic framework), Tala (rhythmic cycle).\nThaat (10 basic scales under Bhatkhande).\nShruti (microtones)." },
              { "label": "Major styles: Dhrupad (oldest, austere, Tan Sen), Khayal (popular, improvised, two parts – Bada and Chota Khayal), Thumri (light, romantic), Tappa (fast, camel drivers), Tarana (syllables)." }
            ]
          },
          {
            "label": "Gharanas (Schools)",
            "children": [
              { "label": "Vocal: Gwalior (oldest, Khayal), Agra (Dhrupad influence), Jaipur (Khayal), Kirana (slow tempo, note purity), Patiala (rapid, embellishments), Bhendi Bazaar." },
              { "label": "Instrumental: Maihar (Baba Allauddin Khan – Sitar, Sarod), Etawah (Imaad Khani – Sitar), Banaras (Sitar), etc." }
            ]
          },
          {
            "label": "Key Instruments",
            "children": [
              { "label": "String: Sitar, Sarod, Veena (Rudra, Vichitra), Sarangi, Dilruba, Violin.\nWind: Flute (Bansuri), Shehnai, Nadaswaram (Carnatic).\nPercussion: Tabla, Pakhawaj, Mridangam." },
              { "label": "Modern: Harmonium (originally European), Santoor, Guitar (Mohan veena)." }
            ]
          },
          {
            "label": "Famous Musicians (Historic & Modern)",
            "children": [
              { "label": "Tan Sen (Akbar's court, Dhrupad), Baiju Bawra.\nSwami Haridas (guru of Tan Sen)." },
              { "label": "Instrumentalists: Ustad Bismillah Khan (Shehnai, Bharat Ratna), Pandit Ravi Shankar (Sitar), Ustad Vilayat Khan, Ustad Amjad Ali Khan (Sarod), Pandit Shivkumar Sharma (Santoor), Pandit Hari Prasad Chaurasia (Flute)." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Carnatic Classical Music",
        "children": [
          {
            "label": "Basic Concepts",
            "children": [
              { "label": "Kriti (main composition), Raga, Tala.\nTrinity: Tyagaraja, Muthuswami Dikshitar, Syama Sastri.\nAnnamacharya (earliest, 15th AD) composed thousands of kritis." },
              { "label": "Vocal dominant; instruments: Veena, Mridangam, Violin, Ghatam, Kanjira, Nadaswaram." }
            ]
          },
          {
            "label": "Major Artists",
            "children": [
              { "label": "M.S.\nSubbulakshmi (first Indian musician at UN), M.\nBalamuralikrishna, L.\nSubramaniam (violin), U.\nSrinivas (mandolin)." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Folk Music & Musical Instruments (Statewise high‑yield)",
        "children": [
          { "label": "Bhangra (Punjab), Bihu (Assam), Garba/Dandiya (Gujarat), Lavni (Maharashtra), Pandavani (CG, Teejan Bai), Baul (Bengal, UNESCO ICH), Nattupura (TN), Pankhida (Rajasthan)." },
          { "label": "Instruments: Algoza (Punjab, double flute), Ektara (Baul), Ravanhatta (Rajasthan, bowed), Tumbi (Punjab), Nagada (percussion), Mashak (HP, bagpipe), Been/Jogi Sarang (snake charmer)." }
        ]
      }
    ]
  },
  // =========================== CHAPTER VI ===========================
  {
    "id": "VI",
    "p": "pm2",
    "label": "Indian Theatre, Puppetry & Cinema",
    "children": [
      {
        "p": "pm2",
        "label": "Traditional & Folk Theatre Forms",
        "children": [
          { "label": "Sanskrit Theatre: Bharata's Natyashastra, plays of Bhasa, Kalidasa, Shudraka, Vishakhadatta.\nKoodiyattam (Kerala, UNESCO ICH) – oldest surviving Sanskrit theatre." },
          { "label": "Folk: Ramlila/Raslila (UP), Bhavai (Gujarat), Tamasha (Maharashtra), Yakshagana (Karnataka), Therukoothu (TN), Jatra (Bengal), Bhand Pather (J&K), Ankiya Nat (Assam, Sankaradeva), Nautanki (UP), Swang (Haryana)." },
          { "label": "MAINS: Folk theatre served as a medium of social and religious instruction, blending entertainment with moral and cultural values." }
        ]
      },
      {
        "p": "pm2",
        "label": "Puppetry Traditions (String, Shadow, Glove, Rod)",
        "children": [
          { "label": "String Puppets (Kathputli – Rajasthan, traditional wooden puppets with strings; Putul Nach – Assam; Bommalattam – TN)." },
          { "label": "Shadow Puppets (Tholu Bommalata – Andhra; Togalu Gombeya – Karnataka; Chamadyacha Bahulya – Maharashtra; Ravanachhaya – Odisha)." },
          { "label": "Glove Puppets (Pavakoothu – Kerala; Beni Putul – WB; Gulabo Sitabo – UP)." },
          { "label": "Rod Puppets (Putul Nach – WB, Yampuri – Bihar, Kathi Kundhei – Odisha)." },
          { "label": "UNESCO ICH: traditional puppetry of Andhra (Tholu Bommalata) and Rajasthan (Kathputli) are recognised." }
        ]
      },
      {
        "label": "Indian Cinema – Milestones",
        "children": [
          { "label": "First feature film: Raja Harishchandra (Dadasaheb Phalke, 1913).\nFirst talkie: Alam Ara (Ardeshir Irani, 1931)." },
          { "label": "Satyajit Ray (Pather Panchali, Apu Trilogy, Oscar Lifetime), Mrinal Sen, Ritwik Ghatak." },
          { "label": "Modern: regional cinemas, international recognition (Oscars, Cannes)." }
        ]
      }
    ]
  },
  // =========================== CHAPTER VII ===========================
  {
    "id": "VII",
    "p": "pm2",
    "label": "Languages & Literature of India",
    "children": [
      {
        "p": "pm2",
        "label": "Classical Languages & Important Works",
        "children": [
          { "label": "Sanskrit (Vedas, Epics, Puranas, classical poetry – Kalidasa, etc.), Tamil (Sangam literature, Tirukkural, Silappadikaram), Pali (Tripitaka, Milindapanho), Prakrit/Ardhamagadhi (Jain canon)." },
          { "label": "Classical status languages (6 originally, later 5 more added – total 11): Tamil, Sanskrit, Kannada, Telugu, Malayalam, Odia (2014), plus later additions." },
          { "label": "Key ancient authors: Panini (Ashtadhyayi – Sanskrit grammar), Patanjali (Mahabhashya), Bhasa (Swapnavasavadatta), Kalidasa (Abhijnanashakuntalam, Meghaduta), Bhavabhuti (Uttararamacharita), Dandin (Kavyadarsha)." }
        ]
      },
      {
        "p": "pm2",
        "label": "Medieval Literature (Bhakti & Sufi)",
        "children": [
          { "label": "Bhakti (Hindi): Kabir (Bijak), Surdas (Sur Sagar, Vinaya Patrika), Tulsidas (Ramcharitmanas), Mirabai (Padavali), Jnaneshwar (Dnyaneshwari – Marathi), Eknath, Namdev, Tukaram." },
          { "label": "Sufi: Amir Khusrau (inventor of Sitar, Tabla, Qawwali, Persian/Hindavi poetry), Malik Muhammad Jayasi (Padmavat, Awadhi), Bulleh Shah (Punjabi)." },
          { "label": "Other regional: Adikavi Pampa (Kannada, Adipurana), Nannaya, Tikkana (Telugu).\nMahakavi Bharathi (Tamil, freedom poetry)." }
        ]
      },
      {
        "p": "pm2",
        "label": "Modern Literature (19th‑20th Century)",
        "children": [
          { "label": "Bengal Renaissance: Bankim Chandra Chattopadhyay (Anandamath – Vande Mataram), Rabindranath Tagore (Gitanjali, Nobel 1913), Sarat Chandra Chattopadhyay (Devdas)." },
          { "label": "Hindi: Munshi Premchand (Godaan, Kafan), Jaishankar Prasad (Kamayani), Mahadevi Verma, Sumitranandan Pant." },
          { "label": "Other languages: Subramania Bharati (Tamil), Kuvempu (Kannada), Faiz Ahmed Faiz (Urdu), Qurratulain Hyder, Kazi Nazrul Islam (Bengal, national poet of Bangladesh)." },
          { "label": "English: R.K.\nNarayan (Malgudi Days), Mulk Raj Anand (Coolie, Untouchable), Arundhati Roy (God of Small Things, Booker), Vikram Seth (A Suitable Boy)." }
        ]
      }
    ]
  },
  // =========================== CHAPTER VIII ===========================
  {
    "id": "VIII",
    "p": "pm2",
    "label": "Religion, Philosophy & Cultural Institutions",
    "children": [
      {
        "p": "pm2",
        "label": "Major Religious & Philosophical Movements (Cultural aspects)",
        "children": [
          { "label": "Buddhism: Three Pitakas, Jatakas, Mahayana and Hinayana; Bodhisattvas, Vajrayana.\nFamous sites: Bodh Gaya, Sarnath, Sanchi, Nalanda, Ajanta." },
          { "label": "Jainism: 24 Tirthankaras, Digambara/Svetambara, art (Gomateshwara, Dilwara temples), literature (Angas, Kalpasutra)." },
          { "label": "Bhakti Movement: Alvars & Nayanars (Tamil), Varkari (Maharashtra), Ramanuja, Chaitanya Mahaprabhu (Gaudiya Vaishnavism), Kabir, Nanak (Sikhism), Ravidas, Dadu Dayal." },
          { "label": "Sufism: Chishti (Moinuddin Chishti – Ajmer, Nizamuddin Auliya – Delhi, Qutbuddin Bakhtiyar Kaki), Suhrawardi, Naqshbandi (Ahmad Sirhindi), Qadiri.\nKey concepts: Pir, Murid, Khanqah, Sama/Qawwali." },
          { "label": "MAINS: Bhakti and Sufi movements bridged social divides, promoted vernacular languages, and contributed to syncretic Indian culture." }
        ]
      },
      {
        "p": "pm2",
        "label": "UNESCO World Heritage Sites – Cultural (Static list)",
        "children": [
          { "label": "Agra Fort, Ajanta Caves, Ellora Caves, Taj Mahal, Group of Monuments at Mahabalipuram, Sun Temple Konark, Churches and Convents of Goa, Khajuraho Group of Monuments, Hampi, Fatehpur Sikri, Pattadakal, Elephanta Caves, Brihadeshwara Temple (Thanjavur), Sanchi Stupa, Humayun's Tomb, Qutb Minar, Mountain Railways (Darjeeling, Nilgiri, Kalka‑Shimla), Mahabodhi Temple, Rock Shelters of Bhimbetka, Chhatrapati Shivaji Terminus, Champaner‑Pavagadh, Red Fort, Jantar Mantar (Jaipur), Hill Forts of Rajasthan, Rani ki Vav (Gujarat), Great Himalayan National Park (also natural), Nalanda Mahavihara, Architectural Work of Le Corbusier (Chandigarh), Historic City of Ahmedabad, Victorian Gothic and Art Deco Ensembles of Mumbai, Jaipur City, Kakatiya Rudreshwara (Ramappa) Temple, Dholavira, Santiniketan, Hoysala Temples (Belur, Halebid), etc." }
        ]
      },
      {
        "p": "pm2",
        "label": "UNESCO Intangible Cultural Heritage (ICH) from India (Static list)",
        "children": [
          { "label": "Kumbh Mela, Yoga, Durga Puja in Kolkata, Garba of Gujarat, Nowruz, Ramlila, Vedic Chanting, Ramman (Uttarakhand), Kalbelia dance, Chhau dance, Buddhist chanting of Ladakh, Sankirtana of Manipur, Traditional brass and copper craft of Thatheras (Punjab), Nawrouz, Koodiyattam, Mudiyettu, etc." }
        ]
      },
      {
        "p": "pm2",
        "label": "Important Cultural Awards & Institutions",
        "children": [
          { "label": "Sangeet Natak Akademi (1952), Lalit Kala Akademi (1954), Sahitya Akademi (1954), National School of Drama (1959)." },
          { "label": "Awards: Padma Shri/Bhushan/Vibhushan, Sangeet Natak Akademi Awards, Sahitya Akademi Award, Kalidas Samman, Saraswati Samman, Jnanpith Award (literature), Dadasaheb Phalke Award (cinema)." },
          { "label": "Cultural festivals: Khajuraho Dance Festival, Taj Mahotsav, Konark Festival, India Art Fair, Surajkund Crafts Mela." }
        ]
      },
      {
        "label": "Miscellaneous Quick Facts (Costumes, Martial Arts, etc.)",
        "children": [
          { "label": "Traditional costumes: Mundum Neriyathum (Kerala), Mekhela Chador (Assam), Phanek (Manipur), Ghagra Choli (Rajasthan/Gujarat)." },
          { "label": "Indian martial arts: Kalaripayattu (Kerala), Silambam (TN), Thang‑Ta (Manipur), Gatka (Punjab), Mardani Khel (Maharashtra)." }
        ]
      }
    ]
  },
  // =========================== CHAPTER IX ===========================
  {
    "id": "IX",
    "p": "pm2",
    "label": "Material Culture: Pottery, Coins & Artefacts",
    "children": [
      {
        "p": "pm2",
        "label": "Pottery Traditions (Chronological)",
        "children": [
          {
            "label": "Pre‑Historic & Proto‑Historic",
            "children": [
              { "label": "Neolithic: handmade, coarse, rarely painted.\nChalcolithic: black‑and‑red ware (BRW), ochre coloured pottery (OCP) found in Upper Ganga valley." },
              { "label": "Harappan: wheel‑turned, red & black pottery with geometric/animals, polychrome, perforated jars; graceful shapes, baking techniques." }
            ]
          },
          {
            "label": "Vedic & Later",
            "children": [
              { "label": "Painted Grey Ware (PGW, 1200‑600 BC): associated with later Vedic period, thin, fine, grey colour, painted with simple patterns; sites – Hastinapur, Ahichhatra." },
              { "label": "Northern Black Polished Ware (NBPW, 700‑100 BC): shiny, black, wheel‑made, hallmark of Mauryan period; used for luxury items; traded widely." }
            ]
          },
          {
            "label": "Historical & Medieval",
            "children": [
              { "label": "Gupta & post‑Gupta: stamped pottery, terracotta figurines, moulded bricks." },
              { "label": "Delhi Sultanate: glazed pottery with Persian influence, blue‑and‑white ware.\nMughal: elaborate ceramic, porcelain, painted tiles in architecture." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Coinage (Punch‑Marked to Modern)",
        "children": [
          {
            "label": "Ancient India",
            "children": [
              { "label": "Punch‑marked coins (6th‑2nd BC): silver & copper, irregular shapes, struck with symbols; earliest coins in India (Mahajanapadas)." },
              { "label": "Indo‑Greeks (2nd‑1st BC): first to issue gold coins in India, with ruler portraits and bilingual inscriptions (Greek and Kharosthi)." },
              { "label": "Kushanas (1st‑2nd AD): gold coins, high purity, Greek & Kharosthi legends, images of deities (Shiva, Buddha)." },
              { "label": "Gupta (4th‑6th AD): gold dinars, high artistic merit, king portraits, reverse deities (Lakshmi, Durga); silver coins for trade.\nDebasement visible in later Guptas." }
            ]
          },
          {
            "label": "Medieval & Modern",
            "children": [
              { "label": "Delhi Sultanate: introduced Silver Tanka and Copper Jital; Alauddin Khilji’s gold coins; Sher Shah Suri’s Silver Rupiya (standard weight)." },
              { "label": "Mughal: gold Mohur, silver Rupiya, copper Dam.\nAkbar’s coins with Din‑i‑Ilahi symbols; Jahangir’s zodiac coins." },
              { "label": "British: Uniform coinage (1835), portrait series of kings; later independent India adopted decimal system (1957, Naya Paisa)." }
            ]
          }
        ]
      }
    ]
  }
] satisfies RawSubjectNode[];