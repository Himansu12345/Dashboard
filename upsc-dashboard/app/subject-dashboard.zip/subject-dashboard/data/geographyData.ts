import type { RawSubjectNode } from "../types";

export const RAW_D = [
  // =========================== CHAPTER I ===========================
  {
    "id": "I",
    "p": "pm",
    "label": "Physical Geography: Geomorphology & Earth’s Structure",
    "children": [
      {
        "p": "pm3",
        "label": "Universe & Solar System",
        "children": [
          {
            "label": "Origin & Galaxies",
            "children": [
              { "label": "Big Bang Theory: Proposed by Georges Lemaître; universe origin ~13.8 billion years ago." },
              { "label": "Galaxy: Milky Way (spiral shape).\nNearest major galaxy: Andromeda." },
              { "label": "Goldilocks Zone: Habitable zone around a star where temperature allows liquid water to exist." },
              { "label": "Heliopause & Oort Cloud: Heliopause is the boundary where solar wind stops; Oort Cloud is a theoretical shell of icy objects." }
            ]
          },
          {
            "label": "Solar System Fundamentals",
            "children": [
              { "label": "Inner Planets (Terrestrial): Mercury, Venus, Earth, Mars.\nSolid, dense, no rings, silicates/metals." },
              { "label": "Outer Planets (Gas/Ice Giants): Jupiter, Saturn, Uranus, Neptune.\nLow density, rings, H/He atmospheres." },
              { "label": "TRAP: Venus is hottest (runaway greenhouse), not Mercury.\nMercury fastest revolution." },
              { "label": "Rotation Anomaly: Venus & Uranus rotate East to West (retrograde)." },
              { "label": "Dwarf planets: Pluto, Ceres, Eris, Haumea, Makemake.\nAsteroid belt between Mars & Jupiter; Kuiper Belt beyond Neptune (short-period comets)." },
              { "label": "Comets: Short period (<200 yrs) from Kuiper Belt; long period from Oort Cloud.\nNucleus (dirty snowball), coma, ion tail (always away from Sun)." },
              { "label": "Meteoroids, Meteors, Meteorites: Meteoroid – small rock in space; Meteor – burning in atmosphere (shooting star); Meteorite – reaches Earth’s surface." }
            ]
          },
          {
            "label": "Earth’s Motions",
            "children": [
              { "label": "Rotation (West to East): Causes day/night, tides, Coriolis effect.\nVelocity max at equator, zero at poles." },
              { "label": "Revolution: Causes seasons with axial tilt (23.5°)." },
              { "label": "Perihelion (Jan 3), Aphelion (July 4)." },
              { "label": "Solstices: Summer (June 21, longest day NH), Winter (Dec 22).\nEquinoxes: March 21 & Sept 23 (equal day/night)." },
              { "label": "Precession of Equinoxes: Earth’s wobble cycle ~26,000 years.\nAffects star positions." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Earth’s Interior & Materials",
        "children": [
          {
            "label": "Structure of the Earth",
            "children": [
              { "label": "Crust: Continental (SIAL, thick up to 70km, granitic, older) vs Oceanic (SIMA, thin ~5km, basaltic, younger)." },
              { "label": "Mantle: Upper mantle has Asthenosphere (plastic, magma source).\nLower mantle solid.\nLithosphere = Crust + uppermost solid mantle." },
              { "label": "Core: Outer core (liquid, magnetic field via dynamo effect).\nInner core (solid, NiFe, extreme pressure)." },
              { "label": "Geomagnetism: Earth’s magnetic field due to convection in liquid outer core.\nMagnetic poles shift; paleomagnetism records sea-floor spreading." }
            ]
          },
          {
            "label": "Seismic Discontinuities (Mnemonic: CMRGL)",
            "children": [
              { "label": "Conrad: Upper/Lower Crust (not globally continuous)." },
              { "label": "Mohorovičić (Moho): Lower Crust/Upper Mantle." },
              { "label": "Repetti: Upper/Lower Mantle." },
              { "label": "Gutenberg: Lower Mantle/Outer Core." },
              { "label": "Lehmann: Outer/Inner Core." }
            ]
          },
          {
            "label": "Rocks & Rock Cycle",
            "children": [
              { "label": "Igneous: Primary, from cooling magma/lava.\nIntrusive (granite, slow cooling, large crystals) vs Extrusive (basalt, fast cooling, fine crystals).\nNo fossils." },
              { "label": "Sedimentary: Secondary, lithification, stratified, porous, contain fossils.\nE.g., sandstone, limestone, shale, coal." },
              { "label": "Metamorphic: Changed by heat/pressure.\nLimestone → Marble; Sandstone → Quartzite; Shale → Slate/Schist; Granite → Gneiss; Coal → Graphite/Diamond." },
              { "label": "Rock Cycle: Igneous → weathering → sedimentary → burial/metamorphism → metamorphic → melting → magma → igneous." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Geodynamics & Isostasy",
        "children": [
          {
            "label": "Continental Drift & Sea-floor Spreading",
            "children": [
              { "label": "Wegener’s Continental Drift: Jigsaw fit, fossil evidence (Glossopteris, Mesosaurus), paleoclimatic evidence.\nRejected due to lack of mechanism." },
              { "label": "Sea-floor Spreading (Hess & Dietz): New crust formed at mid-ocean ridges, moves outward, destroyed at trenches.\nEvidence: magnetic striping, age of sea floor." }
            ]
          },
          {
            "label": "Plate Tectonics (Unifying Theory)",
            "children": [
              { "label": "Major plates: Pacific, North American, South American, Eurasian, African, Indo-Australian, Antarctic, Nazca." },
              { "label": "Driving forces: Mantle convection, slab pull, ridge push." }
            ]
          },
          {
            "label": "Isostasy",
            "children": [
              { "label": "Airy’s theory: Mountains have deep roots (uniform density, varying thickness).\nPratt’s theory: Uniform depth of compensation, lateral density variation." },
              { "label": "Isostatic rebound: Post-glacial uplift of Scandinavia and Canada." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Plate Boundaries & Features",
        "children": [
          {
            "label": "Divergent (Constructive)",
            "children": [
              { "label": "Mid-ocean ridges, rift valleys, new crust (e.g., Mid-Atlantic Ridge, Great East African Rift).\nBasaltic volcanism." }
            ]
          },
          {
            "label": "Convergent (Destructive)",
            "children": [
              { "label": "Ocean-Continent: Subduction → deep trenches, volcanic fold mountains (Andes, Rockies).\nWadati-Benioff zone." },
              { "label": "Ocean-Ocean: Trenches, volcanic island arcs (Japan, Philippines, Aleutians)." },
              { "label": "Continent-Continent: Fold mountains (Himalayas, Alps).\nNo active volcanoes but massive earthquakes." }
            ]
          },
          {
            "label": "Transform (Conservative)",
            "children": [
              { "label": "Strike-slip faults (San Andreas).\nNo creation/destruction.\nOften connect segments of mid-ocean ridges." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Earthquakes & Volcanoes",
        "children": [
          {
            "label": "Earthquake Terminology & Measurement",
            "children": [
              { "label": "Focus (Hypocenter) vs Epicenter (surface above)." },
              { "label": "Seismic waves: P-waves (fastest, through solid/liquid/gas), S-waves (only solids), L-waves (surface, slowest, most destructive)." },
              { "label": "Shadow zones: S-waves beyond 105° → liquid outer core.\nP-wave shadow 105°–145°." },
              { "label": "Richter scale (magnitude, logarithmic, each unit = 10x amplitude, ~32x energy).\nMercalli scale (intensity I-XII, based on damage)." }
            ]
          },
          {
            "label": "Volcano Types & Landforms",
            "children": [
              { "label": "Shield volcano: Gentle slopes, basaltic lava, low viscosity (Mauna Loa, Hawaii)." },
              { "label": "Stratovolcano / Composite: Steep, alternating ash and lava, explosive (Mt.\nFuji, Mt.\nVesuvius)." },
              { "label": "Caldera: Collapse after massive eruption (Yellowstone, Krakatoa)." },
              { "label": "Cinder cone: Small, steep, pyroclastic fragments." },
              { "label": "Hotspot volcanism: Mantle plume beneath plate, chain of islands (Hawaii, Yellowstone).\nDeccan Traps linked to Réunion hotspot." },
              { "label": "Pacific Ring of Fire: 75% active volcanoes, intense seismicity along convergent boundaries." }
            ]
          },
          {
            "label": "Intrusive Igneous Landforms",
            "children": [
              { "label": "Batholith: Large, discordant, granitic mass.\nLaccolith: Dome-shaped concordant intrusion.\nSill: Horizontal concordant.\nDyke: Vertical discordant cutting across strata." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Endogenic & Exogenic Forces",
        "children": [
          {
            "label": "Endogenic (Internal)",
            "children": [
              { "label": "Diastrophism: Orogenic (mountain building, folding/faulting, horizontal) & Epeirogenic (continental uplift/subsidence, vertical)." },
              { "label": "Sudden movements: Earthquakes, volcanic eruptions." }
            ]
          },
          {
            "label": "Exogenic (External) Processes",
            "children": [
              { "label": "Weathering (in-situ breakdown): Physical (frost action, exfoliation), Chemical (oxidation, carbonation, hydration, solution), Biological (roots, lichens)." },
              { "label": "Mass Wasting: Gravity-driven movement; creep, flow, slide, fall.\nInfluence of water, slope, vegetation." },
              { "label": "Erosion & Deposition: Agents: water, wind, ice, waves.\nErosion removes material; deposition forms landforms." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Fluvial (River) Landforms & Drainage Patterns",
        "children": [
          {
            "label": "Erosional Landforms (Youth/Mature Stage)",
            "children": [
              { "label": "V-shaped valleys, gorges (deep, narrow), canyons (steep, step-like sides)." },
              { "label": "Potholes, incised meanders, river terraces." },
              { "label": "Waterfalls: formed by hard rock over soft rock; plunge pool at base.\nE.g., Jog Falls (Sharavati), Angel Falls (Venezuela)." }
            ]
          },
          {
            "label": "Depositional Landforms (Old Stage)",
            "children": [
              { "label": "Alluvial fans (at mountain foot), floodplains, natural levees." },
              { "label": "Meanders, ox-bow lakes (cut-off meander), point bars." },
              { "label": "Braided channels (excess sediment, multiple channels)." },
              { "label": "Deltas: Arcuate (Nile, Ganga), Bird-foot (Mississippi), Cuspate (Tiber).\nEstuarine delta (Narmada, Tapti)." }
            ]
          },
          {
            "label": "Drainage Patterns",
            "children": [
              { "label": "Dendritic (tree-like, uniform lithology).\nTrellis (parallel, folded).\nRadial (volcanic cone, dome).\nCentripetal (inland basin).\nRectangular (jointed rocks)." },
              { "label": "Antecedent drainage: River predates uplift and cuts through rising mountains (Indus, Sutlej, Brahmaputra, Kosi)." },
              { "label": "Superimposed drainage: River initially on cover rocks, cuts down to underlying structure irrespective of structure." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Karst, Aeolian, Glacial & Coastal Landforms",
        "children": [
          {
            "label": "Karst (Limestone) Topography",
            "children": [
              { "label": "Erosional: Sinkholes, swallow holes, dolines, uvalas, poljes, limestone pavements (lapies), blind valleys, caves." },
              { "label": "Depositional: Stalactites (ceiling), stalagmites (floor), pillars (when joined).\nCalcite precipitation." }
            ]
          },
          {
            "label": "Aeolian (Wind) Landforms",
            "children": [
              { "label": "Erosional: Mushroom rocks, yardangs, zeugen, blowouts, inselbergs." },
              { "label": "Depositional: Barchan (crescent, horns downwind), Seif (longitudinal), Transverse dunes, Loess (fertile silt).\nPlayas and Bajadas in deserts." }
            ]
          },
          {
            "label": "Glacial Landforms",
            "children": [
              { "label": "Erosional: Cirque (corrie), horn (Matterhorn), arête, U-shaped valley, hanging valley, roches moutonnées, fjords (submerged U-valleys)." },
              { "label": "Depositional: Moraines (terminal, lateral, medial, ground), eskers (sinuous gravel ridges), drumlins (basket of eggs topography), outwash plains, kame terraces." }
            ]
          },
          {
            "label": "Coastal Landforms",
            "children": [
              { "label": "Erosional: Sea cliffs, wave-cut platforms, caves, arches, stacks, stumps." },
              { "label": "Depositional: Beaches, sandbars, barrier islands, spits (hooked), tombolos (connects island to mainland), lagoons." },
              { "label": "Coastlines: Submergent (ria, fjord, Dalmatian) vs Emergent (raised beach, marine terraces)." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER II ===========================
  {
    "id": "II",
    "p": "pm3",
    "label": "Physical Geography: Climatology & Climate Regions",
    "children": [
      {
        "p": "pm3",
        "label": "Atmosphere: Composition & Structure",
        "children": [
          {
            "label": "Composition of Atmosphere",
            "children": [
              { "label": "Permanent gases: N₂ 78%, O₂ 21%, Ar 0.93%.\nVariable: water vapour, CO₂, ozone, dust (hygroscopic nuclei), aerosols." }
            ]
          },
          {
            "label": "Layers of Atmosphere",
            "children": [
              { "label": "Troposphere: Lowest, weather layer, normal lapse rate 6.5°C/km, thickest at equator, tropopause." },
              { "label": "Stratosphere: Ozone layer (absorbs UV), temperature inversion, no weather clouds, ideal for jets, stratopause." },
              { "label": "Mesosphere: Coldest (-100°C), meteors burn, mesopause." },
              { "label": "Thermosphere (Ionosphere): Temperature rises, ionized layers reflect radio waves, auroras, ISS orbit." },
              { "label": "Exosphere: Outermost, merges into space, light gases escape." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Insolation, Heat Budget & Temperature",
        "children": [
          {
            "label": "Insolation & Factors",
            "children": [
              { "label": "Solar constant: ~1361 W/m².\nFactors: latitude, season, time of day, cloud cover, albedo." },
              { "label": "Albedo: Reflectivity; fresh snow highest (~80-90%), dark ocean lowest (~6%).\nEarth’s average albedo ~30%." }
            ]
          },
          {
            "label": "Heat Budget of Earth",
            "children": [
              { "label": "Shortwave radiation from Sun; longwave terrestrial radiation.\nEquilibrium: net radiation balance = 0 at top of atmosphere." },
              { "label": "Greenhouse effect: Natural trapping of heat by GHGs (CO₂, H₂O, CH₄) keeps Earth ~33°C warmer." }
            ]
          },
          {
            "label": "Temperature Distribution & Anomalies",
            "children": [
              { "label": "Horizontal: Isotherms generally parallel to latitude; more irregular in NH due to land-water contrast." },
              { "label": "Vertical: Lapse rate – normal 6.5°C/km.\nInversion: temperature increases with height (valley inversion, subsidence)." },
              { "label": "Factors: Latitude, altitude, land-water distribution, ocean currents, prevailing winds, cloud cover." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Global Pressure Belts & Winds",
        "children": [
          {
            "label": "Pressure Belts (7 belts)",
            "children": [
              { "label": "Equatorial Low (Doldrums): Thermal, intense heating, low pressure, calm winds, ITCZ." },
              { "label": "Subtropical High (Horse Latitudes): Dynamic, subsidence, deserts, clear skies.\nTwo belts (30° N & S)." },
              { "label": "Subpolar Low (60°): Dynamic, rising warm air along polar front." },
              { "label": "Polar High: Thermal, very cold, dense air." }
            ]
          },
          {
            "label": "Planetary Winds",
            "children": [
              { "label": "Trade Winds: NE in NH, SE in SH (0-30°).\nSteady, converge at ITCZ." },
              { "label": "Westerlies: SW in NH, NW in SH (30-60°).\nStronger in SH (Roaring Forties, Furious Fifties)." },
              { "label": "Polar Easterlies: Cold, dry winds from poles (60-90°)." }
            ]
          },
          {
            "label": "Coriolis Force & Jet Streams",
            "children": [
              { "label": "Coriolis Force: Deflects right in NH, left in SH; zero at equator, max at poles.\nAffects wind direction, ocean currents." },
              { "label": "Jet Streams: Upper troposphere westerly winds (Rossby waves).\nSubtropical Jet (STJ) at ~30°, Polar Front Jet (PFJ) at ~60°.\nIndian monsoon influenced by Tropical Easterly Jet (TEJ) and Somali Jet." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Atmospheric Moisture & Precipitation",
        "children": [
          {
            "label": "Humidity & Clouds",
            "children": [
              { "label": "Absolute humidity: g/m³.\nRelative humidity: ratio of actual to saturation at given temp.\nDew point: temp where air saturates." },
              { "label": "Cloud types: High (Cirrus, Cirrostratus, Cirrocumulus), Middle (Altostratus, Altocumulus), Low (Stratus, Stratocumulus, Nimbostratus), Vertical (Cumulus, Cumulonimbus)." }
            ]
          },
          {
            "label": "Precipitation Types & Mechanism",
            "children": [
              { "label": "Convectional: Surface heating, rising air, cumulonimbus, thunderstorms (equatorial regions)." },
              { "label": "Orographic: Wind forced up mountain, windward rain, leeward rain shadow." },
              { "label": "Cyclonic/Frontal: Along fronts, temperate regions." },
              { "label": "Forms: Rain, drizzle, snow, sleet, hail." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Air Masses, Fronts & Temperate Cyclones",
        "children": [
          {
            "label": "Air Masses & Fronts",
            "children": [
              { "label": "Air mass: Large body of air with uniform temperature, humidity.\nClassified by source region (Maritime/Continental, Tropical/Polar/Arctic)." },
              { "label": "Fronts: Boundary between air masses.\nCold front (steep, cumulonimbus, heavy rain), Warm front (gentle, stratus, steady rain).\nOccluded front: cold overtakes warm." }
            ]
          },
          {
            "label": "Temperate (Extra-Tropical) Cyclones",
            "children": [
              { "label": "Form along polar front (35°-65° lat).\nOver land and sea.\nMove West to East.\nDiameter 500-1500 km." },
              { "label": "Stages: Cyclogenesis (wave), mature (open sector, warm & cold fronts), occlusion (system dies).\nInverted 'V' shape." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Tropical Cyclones",
        "children": [
          {
            "label": "Formation Conditions",
            "children": [
              { "label": "Sea surface temp >27°C, Coriolis force (absent 5°N-5°S), low vertical wind shear, pre-existing low, high humidity." },
              { "label": "Energy from latent heat of condensation.\nEye: calm, subsidence; Eyewall: strongest winds, heaviest rain; spiral rainbands." }
            ]
          },
          {
            "label": "Regional Names & Naming",
            "children": [
              { "label": "Hurricane (Atlantic/E North Pacific), Typhoon (NW Pacific), Cyclone (Indian Ocean, S Pacific), Willy-Willy (Australia)." },
              { "label": "Naming by WMO/ESCAP panel; Indian Ocean cyclones named by countries of region." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "World Climatic Regions (Köppen Classification)",
        "children": [
          {
            "label": "Group A: Tropical Humid",
            "children": [
              { "label": "Af (Tropical Wet): 10°N-10°S, rain all year convectional, hot, diurnal range > annual range.\nAmazon, Congo, Indonesia." },
              { "label": "Am (Tropical Monsoon): Seasonal wind reversal, distinct wet summer, dry winter.\nIndia, SE Asia, N Australia." },
              { "label": "Aw (Tropical Savanna): Wet summer, dry winter.\nLlanos (Venezuela), Campos (Brazil), Sahel.\nTall grass, baobab trees." }
            ]
          },
          {
            "label": "Group B: Dry Climates",
            "children": [
              { "label": "BW (Arid/Desert): Subtropical high, cold ocean currents.\nSahara, Thar, Atacama (driest).\nXerophytes." },
              { "label": "BS (Semi-arid/Steppe): Transitional around deserts.\nShort grasses.\nPrairies, Pampas, Veldt, Downs, Steppes." }
            ]
          },
          {
            "label": "Group C: Warm Temperate (Mesothermal)",
            "children": [
              { "label": "Cs (Mediterranean): West coasts 30°-45°, summer dry, winter rain.\nOrchard farming, viticulture." },
              { "label": "Cfa (Humid Subtropical): East coasts 20°-35°, rain year round, monsoon influence.\nRice, tea." },
              { "label": "Cfb (Marine West Coast): West coasts 40°-60°, mild winters, cool summers.\nDeciduous forests." }
            ]
          },
          {
            "label": "Group D: Cold Snow-forest (Microthermal)",
            "children": [
              { "label": "Df (Humid Continental): Only NH, warm summers, severe winters, mixed forests." },
              { "label": "Dw (Subarctic/Taiga): 50°-70°N, largest biome, coniferous forests (pine, spruce, fir).\nLumbering." }
            ]
          },
          {
            "label": "Group E: Polar & Highland",
            "children": [
              { "label": "ET (Tundra): Permafrost, mosses, lichens.\nEF (Ice Cap): Permanent ice (Greenland, Antarctica)." },
              { "label": "H (Highland): Vertical zonation, climate changes with altitude." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER III ===========================
  {
    "id": "III",
    "p": "pm3",
    "label": "Physical Geography: Oceanography",
    "children": [
      {
        "p": "pm2",
        "label": "Ocean Floor Relief",
        "children": [
          {
            "label": "Continental Margin",
            "children": [
              { "label": "Continental Shelf: Shallow, photic zone, rich fisheries, placer deposits, petroleum.\nAverage width 80 km; widest off Siberia." },
              { "label": "Continental Slope: Steep, submarine canyons, turbidity currents, continental rise at base." }
            ]
          },
          {
            "label": "Deep Ocean Basin",
            "children": [
              { "label": "Abyssal Plains: Flattest regions, pelagic oozes, polymetallic nodules (Mn, Ni, Co, Cu)." },
              { "label": "Oceanic Trenches: Deepest parts, convergent subduction.\nMariana Trench (Pacific, deepest ~11km)." },
              { "label": "Mid-Oceanic Ridges: Divergent boundaries, longest mountain chain (Mid-Atlantic Ridge)." },
              { "label": "Seamounts & Guyots: Volcanic origin; guyots flat-topped due to wave erosion before subsidence." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Salinity & Temperature",
        "children": [
          {
            "label": "Salinity Distribution",
            "children": [
              { "label": "Average oceanic salinity: 35 ppt.\nDominant salts: NaCl 77%, MgCl₂ 10.9%, MgSO₄ 4.7%." },
              { "label": "Highest salinity in subtropics (high evaporation, low rain).\nLower at equator (heavy rain) and poles (ice melt)." },
              { "label": "Extremes: Lake Van (330‰), Dead Sea (238‰), Great Salt Lake (220‰)." },
              { "label": "Halocline: rapid change of salinity with depth.\nIsohalines: equal salinity lines." }
            ]
          },
          {
            "label": "Temperature & Density",
            "children": [
              { "label": "Surface temperature decreases poleward.\nNH oceans warmer due to more landmass." },
              { "label": "Thermocline: layer (~300-1000m) of rapid temperature drop; absent at poles." },
              { "label": "Density: Cold salty water densest; drives thermohaline circulation (Global Conveyor Belt)." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Ocean Currents",
        "children": [
          {
            "label": "Atlantic Ocean",
            "children": [
              { "label": "Warm: North Equatorial, Gulf Stream, North Atlantic Drift (keeps NW Europe ice-free), Brazilian." },
              { "label": "Cold: Labrador, Canary, Benguela (Namib Desert), Falkland." },
              { "label": "Grand Banks: Meeting of Gulf Stream & Labrador, rich fisheries.\nSargasso Sea: North Atlantic gyre, Sargassum seaweed." }
            ]
          },
          {
            "label": "Pacific Ocean",
            "children": [
              { "label": "Warm: Kuroshio, East Australian, Alaskan, N & S Equatorial." },
              { "label": "Cold: Oyashio (Kurile), California, Peru (Humboldt – upwelling, El Niño link), West Australian." }
            ]
          },
          {
            "label": "Indian Ocean",
            "children": [
              { "label": "Warm: South Equatorial, Agulhas, Mozambique." },
              { "label": "Cold: West Australian." },
              { "label": "Seasonal reversal: SW monsoon – Somali current (cold upwelling); NE monsoon – warm southward flow." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Tides & Waves",
        "children": [
          {
            "label": "Tides: Causes & Types",
            "children": [
              { "label": "Gravitational pull of Moon (main) & Sun, balanced by centrifugal force." },
              { "label": "Spring Tides: Full & New Moon (Syzygy), maximum range." },
              { "label": "Neap Tides: First & Third Quarter (Quadrature), minimum range." },
              { "label": "Perigean tide (Moon at Perigee) higher; Apogean lower." }
            ]
          },
          {
            "label": "Tidal Phenomena",
            "children": [
              { "label": "Tidal Bore: Steep wave upstream in funnel-shaped rivers (Hooghly, Bay of Fundy)." },
              { "label": "Classification: Semi-diurnal (2 high, 2 low/day), Diurnal (1 high, 1 low), Mixed." }
            ]
          },
          {
            "label": "Waves & Tsunamis",
            "children": [
              { "label": "Wave: orbital motion of water particles; height, length, period.\nTsunami: seismic sea wave, long wavelength, high speed in deep water, devastation near coast." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Coral Reefs & Marine Resources",
        "children": [
          {
            "label": "Coral Reefs",
            "children": [
              { "label": "Symbiosis: Coral polyps (animal) + Zooxanthellae (algae, 90% food/color)." },
              { "label": "Conditions: Warm 20-21°C, shallow <50m, clean saline 27-30 ppt, no sediment." },
              { "label": "Types: Fringing (attached coast), Barrier (separated by lagoon, Great Barrier Reef), Atolls (circular, central lagoon)." },
              { "label": "Bleaching: Expulsion of Zooxanthellae due to stress (warming, acidification).\nRecovery if short; death if prolonged." }
            ]
          },
          {
            "label": "Indian Coral Reefs & Ocean Acidification",
            "children": [
              { "label": "Major Indian reefs: Gulf of Mannar, Gulf of Kutch, A&N (fringing), Lakshadweep (atolls).\nSundarbans no coral (freshwater/sediment)." },
              { "label": "Ocean Acidification: CO₂ → carbonic acid, lowers pH, reduces carbonate ions, harms shell-forming organisms." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER IV ===========================
  {
    "id": "IV",
    "p": "pm3",
    "label": "Indian Geography: Physiography & Drainage",
    "children": [
      {
        "p": "pm3",
        "label": "Physiographic Divisions",
        "children": [
          {
            "label": "The Himalayas",
            "children": [
              { "label": "Longitudinal divisions: Trans-Himalaya (Karakoram, Ladakh, Zaskar – cold desert), Greater Himalaya/Himadri (highest, continuous, granitic core), Lesser Himalaya/Himachal (Pir Panjal, Dhauladhar, hill stations), Shiwaliks (foothills, unconsolidated, duns)." },
              { "label": "Regional (W to E): Punjab/Kashmir, Kumaon, Nepal, Assam Himalayas." },
              { "label": "Syntaxial bends: NW (Nanga Parbat) and NE (Namcha Barwa)." },
              { "label": "Karewas: Glacio-fluvial deposits in Kashmir valley, ideal for saffron (Zafran)." }
            ]
          },
          {
            "label": "Mountain Passes (High-Yield TRAP)",
            "children": [
              { "label": "J&K/Ladakh: Zoji La (Srinagar-Leh), Banihal (Jawahar Tunnel), Khardung La (highest motorable), Aghil Pass (Ladakh-China)." },
              { "label": "Himachal: Shipki La (Sutlej entry), Bara Lacha La, Rohtang Pass." },
              { "label": "Uttarakhand: Niti, Mana, Lipu Lekh (Kailash Mansarovar route)." },
              { "label": "Sikkim/Arunachal: Nathu La, Jelep La; Bomdi La, Diphu Pass (Arunachal-Myanmar)." }
            ]
          },
          {
            "label": "Major Himalayan Peaks",
            "children": [
              { "label": "K2 (Godwin-Austen): Karakoram, PoK, 2nd globally.\nKanchenjunga: highest in India (Sikkim), 3rd globally." },
              { "label": "Nanda Devi: highest entirely within India (Uttarakhand)." },
              { "label": "Namcha Barwa: Eastern anchor (Tibet), Brahmaputra U-turn." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Northern Plains & Peninsular Plateau",
        "children": [
          {
            "label": "Indo-Gangetic Plains (North to South)",
            "children": [
              { "label": "Bhabar: Porous belt at Shiwalik foot, streams disappear." },
              { "label": "Terai: Marshy zone where streams re-emerge, thick forests." },
              { "label": "Bhangar: Older alluvium, higher terraces, Kankar nodules." },
              { "label": "Khadar: Newer alluvium, fertile floodplains, renewed annually." },
              { "label": "Delta Plain: Sundarbans, largest mangrove delta." }
            ]
          },
          {
            "label": "Peninsular Plateau",
            "children": [
              { "label": "Central Highlands: N of Narmada; Malwa, Bundelkhand, Chota Nagpur Plateau (Ruhr of India)." },
              { "label": "Deccan Plateau: S of Narmada, bounded by W & E Ghats.\nDeccan Trap (volcanic basalt, slopes W to E)." },
              { "label": "Western Ghats: Continuous, block mountains, orographic rain.\nPasses: Thal, Bhor, Pal Ghat, Shencottah.\nHighest: Anamudi." },
              { "label": "Eastern Ghats: Discontinuous, relict.\nHighest: Jindhagada/Arma Konda." },
              { "label": "Meeting point: Nilgiri Hills (Doddabetta).\nCardamom Hills southernmost." }
            ]
          },
          {
            "label": "Coastal Plains & Islands",
            "children": [
              { "label": "West Coast: Narrow, submerged, natural ports.\nSections: Kathiawar, Konkan, Kanara, Malabar.\nKayals (backwaters)." },
              { "label": "East Coast: Broad, emergent, deltas, lagoons (Chilika, Pulicat).\nNorthern Circars & Coromandel." },
              { "label": "Andaman & Nicobar: Submerged Arakan Yoma; volcanic, Barren Island (only active volcano).\nTen Degree Channel separates groups." },
              { "label": "Lakshadweep: Coral atolls.\nNine Degree Channel separates Minicoy." },
              { "label": "TRAP: Indira Point (Great Nicobar) southernmost point, not Kanyakumari." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Drainage Systems (Rivers of India)",
        "children": [
          {
            "label": "Himalayan Rivers (Antecedent, Perennial)",
            "children": [
              { "label": "Indus System: Left bank: Jhelum, Chenab, Ravi, Beas, Sutlej (Panjnad).\nRight bank: Shyok, Gilgit, Kabul.\nIndus Water Treaty 1960: India controls Eastern rivers (Ravi, Beas, Sutlej)." },
              { "label": "Ganga System: Formed at Devprayag (Bhagirathi+Alaknanda).\nLeft bank: Ramganga, Gomti, Ghaghara, Gandak, Kosi (Sorrow of Bihar).\nRight bank: Yamuna, Son, Damodar (Sorrow of Bengal)." },
              { "label": "Brahmaputra System: Yarlung Tsangpo in Tibet, U-turn at Namcha Barwa.\nTributaries: Dibang, Lohit, Subansiri, Kameng, Manas, Teesta.\nMajuli (world’s largest riverine island)." }
            ]
          },
          {
            "label": "Peninsular Rivers (Concordant, Seasonal)",
            "children": [
              { "label": "East flowing (Deltas): Subarnarekha, Mahanadi, Godavari (Dakshin Ganga, longest peninsular), Krishna, Penner, Kaveri (steady flow from both monsoons), Vaigai." },
              { "label": "West flowing (Estuaries/Rift valleys): Narmada (Amarkantak), Tapti, Mahi (crosses Tropic of Cancer twice), Sabarmati, Periyar, Mandovi, Zuari." },
              { "label": "Inland drainage: Luni river (Aravallis, endorheic, Rann of Kutch)." }
            ]
          },
          {
            "label": "Major Multipurpose Projects",
            "children": [
              { "label": "North: Bhakra-Nangal (Sutlej), Tehri (Bhagirathi, highest dam), Salal/Baglihar (Chenab)." },
              { "label": "East/Central: Hirakud (Mahanadi, longest earthen dam), Rihand (Son), Sardar Sarovar (Narmada)." },
              { "label": "South: Nagarjuna Sagar (Krishna), Mettur (Kaveri), Idukki (Periyar).\nPolavaram (Godavari), Kaleshwaram Lift Irrigation." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER V ===========================
  {
    "id": "V",
    "p": "pm2",
    "label": "Indian Geography: Climate, Soils & Vegetation",
    "children": [
      {
        "p": "pm3",
        "label": "Indian Monsoon: Mechanism & Seasons",
        "children": [
          {
            "label": "Factors Influencing Indian Monsoon",
            "children": [
              { "label": "Differential heating of land and sea; shift of ITCZ northward; Tibetan Plateau heating; Mascarene High; Somali Jet." },
              { "label": "Jet streams: Sub-Tropical Westerly Jet brings Western Disturbances (winter rain); Tropical Easterly Jet strengthens SW monsoon." },
              { "label": "Teleconnections: El Niño (weakens monsoon), La Niña (strengthens), Indian Ocean Dipole (positive IOD aids monsoon), MJO." }
            ]
          },
          {
            "label": "Seasons & Rainfall",
            "children": [
              { "label": "SW Monsoon (June-Sept): Arabian Sea branch (orographic rain W Ghats) & Bay of Bengal branch (NE India, Gangetic plains)." },
              { "label": "NE Monsoon (Oct-Dec): Retreating monsoon, winds pick moisture from BoB, rain on Coromandel coast." },
              { "label": "Winter: Western Disturbances from Mediterranean, beneficial for Rabi crops." }
            ]
          },
          {
            "label": "Rainfall Distribution",
            "children": [
              { "label": "Highest >200 cm: Mawsynram, Cherrapunji (Khasi hills funnel), windward W Ghats, A&N." },
              { "label": "Lowest <50 cm: W Rajasthan (Thar, Aravalis parallel to winds), N Ladakh (rain shadow)." },
              { "label": "100 cm isohyet divides wetter east/coastal from drier west/interior." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Soils of India (ICAR Classification)",
        "children": [
          {
            "label": "Major Soil Types",
            "children": [
              { "label": "Alluvial (43%): Northern plains & deltas, fertile, potash/lime rich, poor N, P, humus.\nWheat, rice, sugarcane, jute." },
              { "label": "Black/Regur (15%): Deccan basalt, clayey, swells & cracks ('self-ploughing'), moisture retentive.\nRich in Ca, Mg, Al, Fe; poor N, P.\nIdeal for cotton." },
              { "label": "Red & Yellow (18%): Old crystalline rocks, low rainfall.\nRed due to iron oxide; yellow when hydrated.\nPorous, friable.\nMillets, pulses, groundnut." },
              { "label": "Laterite: High temp, alternating wet/dry, intense leaching (desilication).\nPoor organic matter, hardens on exposure.\nTea, coffee, cashew, brick making." }
            ]
          },
          {
            "label": "Minor Soils & Degradation",
            "children": [
              { "label": "Arid/Desert: NW India, sandy, high salts, low moisture.\nIrrigated cultivation (IG Canal)." },
              { "label": "Saline/Alkaline (Usar): Arid & over-irrigated areas; reclaimed with gypsum." },
              { "label": "Peaty/Marshy: High rainfall, heavy dead vegetation, acidic.\nKerala (Kari soils), Sundarbans." },
              { "label": "Soil Degradation: Sheet & gully erosion (Chambal ravines/badlands), salinization, alkalization." },
              { "label": "Conservation: Contour ploughing, terracing, shelterbelts, afforestation, crop rotation." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Natural Vegetation & Forests",
        "children": [
          {
            "label": "Forest Types (Champion & Seth)",
            "children": [
              { "label": "Tropical Wet Evergreen: >200 cm rain, W Ghats, NE, A&N.\nDense multi-layered canopy, no collective shedding.\nMahogany, ebony, rosewood." },
              { "label": "Tropical Semi-Evergreen: Transitional, white cedar, hollock." },
              { "label": "Tropical Moist Deciduous: 100-200 cm, most widespread (Monsoon forests).\nTeak, sal, shisham, bamboo." },
              { "label": "Tropical Dry Deciduous: 70-100 cm, tendu, amaltas, khair." },
              { "label": "Tropical Thorn: <70 cm, Rajasthan, Gujarat.\nKikar, babool, xerophytic." },
              { "label": "Montane: Altitudinal zonation.\nSholas: wet temperate stunted forests + grasslands in Nilgiris, Anamalai." },
              { "label": "Mangroves (Tidal): Salt-tolerant, pneumatophores, vivipary.\nSundarbans, Bhitarkanika, Godavari-Krishna." }
            ]
          },
          {
            "label": "Wildlife & Conservation Areas",
            "children": [
              { "label": "Tiger Reserves: 54+ under Project Tiger (1973).\nJim Corbett (1st), Nagarjunsagar Srisailam (largest).\nHighest tigers: MP, Karnataka, Uttarakhand." },
              { "label": "Elephant Reserves: 33, Project Elephant (1992).\nHighest numbers: Karnataka." },
              { "label": "Biosphere Reserves: 18.\nNilgiri (1st, 1986), Gulf of Mannar, Sundarbans, Agasthyamala.\n12 UNESCO MAB." },
              { "label": "Ramsar Sites: 80+ (2024).\nChilika, Keoladeo (1st).\nMontreux Record: Keoladeo, Loktak; Chilika removed." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER VI ===========================
  {
    "id": "VI",
    "p": "pm3",
    "label": "World Mapping & Geopolitical Regions (Make-or-Break)",
    "children": [
      {
        "p": "pm3",
        "label": "Important Seas & Bordering Countries",
        "children": [
          {
            "label": "The Mediterranean Sea",
            "children": [
              { "label": "Europe: Spain, France, Monaco, Italy, Slovenia, Croatia, Bosnia, Montenegro, Albania, Greece, Malta." },
              { "label": "Africa: Morocco, Algeria, Tunisia, Libya, Egypt." },
              { "label": "Asia: Turkey, Syria, Lebanon, Israel, Palestine." },
              { "label": "TRAP: Jordan, Iraq, Portugal do NOT touch Mediterranean." }
            ]
          },
          {
            "label": "Black, Caspian, Red, Aral & Baltic Seas",
            "children": [
              { "label": "Black Sea: Turkey, Bulgaria, Romania, Ukraine, Russia, Georgia (T-BURG)." },
              { "label": "Caspian Sea: Russia, Iran, Kazakhstan, Turkmenistan, Azerbaijan (TARIK).\nUzbekistan does NOT touch." },
              { "label": "Red Sea: Egypt, Sudan, Eritrea (W); Saudi Arabia, Yemen (E).\nBab-el-Mandeb to Gulf of Aden." },
              { "label": "Aral Sea: Kazakhstan & Uzbekistan only.\nEcological disaster." },
              { "label": "Baltic Sea: Denmark, Estonia, Latvia, Lithuania, Finland, Germany, Poland, Russia, Sweden." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Major Straits & Chokepoints",
        "children": [
          {
            "label": "Asian & Middle Eastern Straits",
            "children": [
              { "label": "Strait of Malacca: Andaman Sea–South China Sea (Malaysia/Indonesia).\nBusiest shipping lane." },
              { "label": "Strait of Hormuz: Persian Gulf–Gulf of Oman (Iran/UAE).\nCritical oil transit." },
              { "label": "Bab-el-Mandeb: Red Sea–Gulf of Aden (Djibouti/Eritrea–Yemen).\n'Gate of Tears'." },
              { "label": "Sunda Strait: Java Sea–Indian Ocean (Sumatra–Java)." },
              { "label": "Palk Strait: Bay of Bengal–Palk Bay/Gulf of Mannar (India–Sri Lanka)." },
              { "label": "Isthmus of Kra: Thailand, proposed canal to bypass Malacca." }
            ]
          },
          {
            "label": "Global Straits & Canals",
            "children": [
              { "label": "Strait of Gibraltar: Atlantic–Mediterranean (Spain–Morocco/UK Gibraltar)." },
              { "label": "Bosphorus & Dardanelles: Black Sea–Marmara–Aegean (Turkey)." },
              { "label": "Bering Strait: Chukchi Sea–Bering Sea (Russia–USA/Alaska), International Date Line passes." },
              { "label": "Strait of Magellan: S America–Tierra del Fuego.\nDrake Passage south." },
              { "label": "Canals: Panama (Pacific–Atlantic, locks).\nSuez (Med–Red Sea, sea-level, reduced route to India)." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Global Mountains, Rivers & Features",
        "children": [
          {
            "label": "Major Mountain Ranges",
            "children": [
              { "label": "Andes (S America, longest continental range)." },
              { "label": "Rockies & Appalachians (N America)." },
              { "label": "Alps (Europe) & Himalayas (Asia) – young fold mountains." },
              { "label": "Ural Mountains (traditional Europe-Asia boundary)." },
              { "label": "Atlas Mountains (N Africa)." },
              { "label": "Great Dividing Range (E Australia)." }
            ]
          },
          {
            "label": "Major River Systems",
            "children": [
              { "label": "Nile: Longest, flows north into Mediterranean." },
              { "label": "Amazon: Largest discharge, crosses equator, flows east into Atlantic." },
              { "label": "Mississippi-Missouri: Longest N America, Gulf of Mexico (bird-foot delta)." },
              { "label": "Mekong: Transboundary (China, Myanmar, Laos, Thailand, Cambodia, Vietnam), NOT India/Bangladesh." },
              { "label": "Danube: 10 countries, into Black Sea." },
              { "label": "Volga: Longest Europe, into Caspian." },
              { "label": "Congo (Zaire): Deepest, crosses equator twice, into Atlantic." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "World Climate Extremes & Regions",
        "children": [
          {
            "label": "Major Deserts",
            "children": [
              { "label": "Hot: Sahara (largest hot), Atacama (driest non-polar, Humboldt Current), Kalahari, Great Australian." },
              { "label": "Cold: Antarctica (largest overall), Gobi (rain shadow Himalayas), Patagonia (rain shadow Andes)." }
            ]
          },
          {
            "label": "Forests & Biodiversity",
            "children": [
              { "label": "Tropical Rainforests: Lungs of planet, Amazon, Congo, SE Asia." },
              { "label": "Biodiversity Hotspots: 36 globally (Norman Myers 1988), high endemism, threatened." },
              { "label": "India's 4 Hotspots: Western Ghats & Sri Lanka, Himalayas, Indo-Burma, Sundaland (includes Nicobar)." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER VII ===========================
  {
    "id": "VII",
    "p": "pm3",
    "label": "Economic Geography & Agriculture",
    "children": [
      {
        "p": "pm3",
        "label": "World Agriculture & Major Crops",
        "children": [
          {
            "label": "Global Crop Belts & Regions",
            "children": [
              { "label": "Wheat (Extensive): Temperate grasslands.\nPrairies (USA/Canada), Pampas (Argentina), Steppes (Ukraine/Russia), Downs (Australia), Veldt (S Africa)." },
              { "label": "Rice (Intensive Subsistence): Monsoon Asia.\nChina, India, Indonesia, Bangladesh, Vietnam." },
              { "label": "Maize: Corn Belt (USA) largest; animal feed & ethanol.\nAlso China, Brazil." },
              { "label": "Cotton: China, India, USA, Pakistan, Brazil." },
              { "label": "Plantation Crops: Coffee (Brazil largest, India shade-grown Arabica/Robusta in W Ghats), Tea (China, India – Assam/Darjeeling, Sri Lanka, Kenya), Rubber (Amazon native, now Thailand, Indonesia, Malaysia, India – Kerala)." }
            ]
          },
          {
            "label": "Types of Shifting Cultivation (Slash and Burn)",
            "children": [
              { "label": "India: Jhumming (NE), Podu (AP/Odisha), Bewar/Dahiya (MP), Kumari (W Ghats)." },
              { "label": "World: Milpa (Mexico/C America), Roca (Brazil), Ladang (Indonesia/Malaysia), Ray (Vietnam), Chena (Sri Lanka)." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Indian Agriculture",
        "children": [
          {
            "label": "Cropping Seasons & Crop Requirements",
            "children": [
              { "label": "Kharif (Monsoon): Sown Jun/Jul, harvested Sep/Oct.\nRice, maize, jowar, bajra, tur, moong, urad, cotton, jute, groundnut, soybean." },
              { "label": "Rabi (Winter): Sown Oct/Dec, harvested Apr/May.\nWheat, barley, peas, gram, mustard, linseed." },
              { "label": "Zaid (Summer): Mar-Jun, irrigated.\nWatermelon, cucumber, vegetables, fodder." },
              { "label": "Climatic needs: Rice (>25°C, >100cm rain, clayey loam, methane emitter).\nWheat (10-15°C growing, bright sun at ripening, 50-75cm rain).\nSugarcane (hot/humid, 21-27°C, frost lethal).\nCotton (210 frost-free days, black Regur soil)." },
              { "label": "MSP: CACP recommends for 22 mandated crops + FRP for sugarcane; 14 Kharif, 6 Rabi, 2 commercial." }
            ]
          },
          {
            "label": "Agricultural Revolutions",
            "children": [
              { "label": "Green Revolution (1960s): HYV seeds (wheat, rice), fertilizers, irrigation.\nPunjab, Haryana, W UP.\nIssues: water depletion, inequality." },
              { "label": "White Revolution (Operation Flood 1970): NDDB, Verghese Kurien (AMUL).\nIndia largest milk producer via dairy cooperatives." },
              { "label": "Other: Blue (fisheries), Yellow (oilseeds), Golden (horticulture/honey), Silver (eggs/poultry)." }
            ]
          },
          {
            "label": "Problems & Reforms",
            "children": [
              { "label": "Fragmentation, low productivity, monsoon dependence, disguised unemployment, credit & marketing issues (APMC monopoly)." },
              { "label": "Reforms: e-NAM, contract farming, PM-KISAN, PM Fasal Bima Yojana, Soil Health Card, organic farming (PKVY)." },
              { "label": "Farm Acts 2020 (repealed 2021): marketing freedom, debate on MSP vs market." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Mineral Resources & Industries",
        "children": [
          {
            "label": "India's Mineral Belts & Mines",
            "children": [
              { "label": "NE Peninsula (Chota Nagpur): Richest belt.\nJharkhand, Odisha, WB, Chhattisgarh.\nCoal (Damodar), iron, manganese, bauxite, mica (Koderma)." },
              { "label": "Central/Southern (Dharwar, Karnataka): High-grade iron (Kudremukh/Sandur), gold (Kolar/Hutti), lacks good coal." },
              { "label": "Specific mines: Bailadila (CG, hematite, export to Japan via Vizag), Khetri (Rajasthan copper), Singhbhum (copper), Jaduguda (uranium), Tummalapalle (AP uranium)." },
              { "label": "Coal: Gondwana (98% reserves, bituminous, 250 my) in Damodar, Mahanadi, Godavari, Wardha.\nTertiary (lignite/peat, 15-60 my) in TN Neyveli, Assam, Meghalaya." }
            ]
          },
          {
            "label": "Key Industries & Location Factors",
            "children": [
              { "label": "Iron & Steel: Weight-losing; near coal/iron.\nJamshedpur (Tata), Bokaro, Durgapur, Rourkela, Bhilai, Visakhapatnam (port-based)." },
              { "label": "Aluminium: Power-intensive; cheap electricity primary.\nKorba (CG), Renukoot (UP), NALCO (Odisha)." },
              { "label": "Textiles: Proximity to cotton, humid climate.\nMumbai, Ahmedabad (Manchester of India), Coimbatore.\nJute: Hooghly basin (water for retting)." },
              { "label": "Challenges: Land acquisition, environmental clearances, infrastructure, global competition." }
            ]
          },
          {
            "label": "Critical Global Minerals",
            "children": [
              { "label": "Lithium: 'Triangle' – Argentina, Bolivia, Chile (salt flats).\nAustralia largest hard-rock producer." },
              { "label": "Cobalt: DRC dominates (>70%), human rights concerns." },
              { "label": "Rare Earth Elements (REEs): 17 elements for electronics; China dominates mining & refinement." },
              { "label": "Uranium: Kazakhstan (in-situ), Canada, Australia (largest reserves)." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Transport & Communication",
        "children": [
          {
            "label": "Indian Railways & Roadways",
            "children": [
              { "label": "Railways: 18+ zones.\nDedicated Freight Corridors: Eastern (Ludhiana-Dankuni), Western (Dadri-JNPT)." },
              { "label": "Roadways: NH 44 (Srinagar-Kanyakumari, longest), NH 16 (East Coast), NH 48 (Delhi-Mumbai-Chennai).\nGolden Quadrilateral, N-S & E-W Corridors (intersect at Jhansi)." }
            ]
          },
          {
            "label": "Ports & Waterways",
            "children": [
              { "label": "Major Ports (12 govt): West – Mumbai (largest), JNPT (most container), Kandla (tidal), Mormugao, Mangalore, Kochi.\nMundra (largest private).\nEast – Chennai (oldest artificial), Tuticorin, Visakhapatnam (deepest landlocked), Paradip, Kolkata/Haldia (riverine, needs dredging)." },
              { "label": "NWs: NW-1 (Ganga, Haldia-Allahabad), NW-2 (Brahmaputra, Dhubri-Sadiya), NW-3 (West Coast Canal, Kerala), NW-4 (Godavari-Krishna)." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER VIII ===========================
  {
    "id": "VIII",
    "p": "pm2",
    "label": "Social Geography & Demography",
    "children": [
      {
        "p": "pm2",
        "label": "Population Dynamics",
        "children": [
          {
            "label": "Census 2011 Highlights",
            "children": [
              { "label": "Total: 1.21 billion, 17.5% world pop on 2.4% land.\nMost populous: UP > Maharashtra > Bihar > WB." },
              { "label": "Density: National 382/km².\nHighest: Bihar (1106); lowest: Arunachal (17)." },
              { "label": "Sex Ratio: 940.\nBest: Kerala (1084); worst: Haryana (879).\nChild sex ratio 0-6: 919." },
              { "label": "Literacy: 74.04% (M 82.14%, F 65.46%).\nHighest: Kerala (93.91%); lowest: Bihar (61.80%)." }
            ]
          },
          {
            "label": "Demographic Trends",
            "children": [
              { "label": "Demographic Dividend: Working-age (15-59) >62%, dependency ratio declining.\nPotential if skilled & employed." },
              { "label": "Growth rate: decadal 17.7%, slowing.\nTFR 2.0 (NFHS-5, 2019-21); many states below replacement level 2.1." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Migration & Urbanization",
        "children": [
          {
            "label": "Migration Patterns",
            "children": [
              { "label": "Push factors: rural poverty, unemployment, lack of amenities.\nPull factors: urban jobs, higher wages, better services." },
              { "label": "Inter-state migration: Rural-to-Rural dominant (female marriage migration); Rural-to-Urban (male economic)." }
            ]
          },
          {
            "label": "Urbanization Initiatives",
            "children": [
              { "label": "Urban population 31.16% (2011).\nHighest %: TN; highest absolute: Maharashtra." },
              { "label": "Mega Cities (>10m): Mumbai, Delhi, Kolkata, Bengaluru, Chennai, Hyderabad, Ahmedabad." },
              { "label": "Smart Cities Mission: 100 cities, sustainable infra, IT solutions.\nAMRUT: urban basic services.\nPMAY (Urban): Housing for All." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Scheduled Tribes & Indigenous People",
        "children": [
          {
            "label": "Tribal Demographics",
            "children": [
              { "label": "Largest ST population: MP > Maharashtra > Odisha." },
              { "label": "Highest % ST: Lakshadweep (94.8%), Mizoram (94.4%), Nagaland, Meghalaya." },
              { "label": "TRAP: Punjab, Haryana, Chandigarh, Delhi, Puducherry have no notified STs." }
            ]
          },
          {
            "label": "PVTGs & Movements",
            "children": [
              { "label": "PVTGs: 75 groups (Dhebar Commission).\nPre-agricultural technology, stagnant population, low literacy." },
              { "label": "Key PVTGs: Sentinelese, Jarawa, Onge, Shompen (A&N); Bonda (Odisha); Cholanaikkans (Kerala); Sahariya (MP/Rajasthan)." },
              { "label": "Tribal movements: Birsa Munda Ulgulan, Santhal Hul.\nBhuria Committee led to PESA Act 1996 (empowering Gram Sabhas in Schedule V areas)." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Population & Migration Theories (Mains Focus)",
        "children": [
          {
            "label": "Malthusian Theory",
            "children": [
              { "label": "Population grows geometrically, food arithmetically.\nPositive checks (famine, disease) and preventive checks (moral restraint).\nCriticised for ignoring tech progress." }
            ]
          },
          {
            "label": "Marxian Perspective",
            "children": [
              { "label": "Surplus population relative to employment under capitalism; not absolute overpopulation.\nA result of capitalist system." }
            ]
          },
          {
            "label": "Demographic Transition Model (DTM)",
            "children": [
              { "label": "Stage 1: High stationary; Stage 2: Early expanding; Stage 3: Late expanding; Stage 4: Low stationary; Stage 5: Declining." },
              { "label": "India: Stage 3 (declining birth rate, high momentum).\nSouthern states moving to Stage 4." }
            ]
          },
          {
            "label": "Optimum Population Theory",
            "children": [
              { "label": "Ideal population size that maximises per capita output given resources and technology.\nUnder/overpopulation relative to optimum." }
            ]
          },
          {
            "label": "Ravenstein’s Laws of Migration (1885)",
            "children": [
              { "label": "Short distance; steps; long-distance to great centres; counter-current; urban dwellers less migratory; women short-distance; economic reasons dominant." }
            ]
          },
          {
            "label": "Lee’s Push-Pull Model",
            "children": [
              { "label": "Migration decision influenced by push (origin), pull (destination), intervening obstacles, personal factors." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER IX ===========================
  {
    "id": "IX",
    "p": "pm3",
    "label": "Geography-Environment Overlap & Current Affairs Static",
    "children": [
      {
        "p": "pm3",
        "label": "Protected Areas & Rivers Flowing Through",
        "children": [
          {
            "label": "National Parks & Rivers",
            "children": [
              { "label": "Jim Corbett NP (Uttarakhand): Ramganga." },
              { "label": "Kaziranga NP (Assam): Brahmaputra, Diphlu, Mora Dhansiri.\nOne-horned Rhino." },
              { "label": "Silent Valley NP (Kerala): Kunthi river." },
              { "label": "Manas NP (Assam): Manas river (right-bank Brahmaputra), contiguous with Bhutan." },
              { "label": "Namdapha NP (Arunachal): Noa-Dihing river, biodiversity hotspot." }
            ]
          },
          {
            "label": "Tiger Reserves & Rivers",
            "children": [
              { "label": "Panna TR (MP): Ken river (Ken-Betwa link)." },
              { "label": "Sathyamangalam TR (TN): Moyar river, corridor between W and E Ghats." },
              { "label": "Sundarbans NP (WB): Tidal estuaries (Matla, Bidya)." }
            ]
          }
        ]
      },
      {
        "p": "pm3",
        "label": "Biosphere Reserves & Ramsar Sites",
        "children": [
          {
            "label": "Biosphere Reserves (BR)",
            "children": [
              { "label": "18 BRs.\nNewest: Panna (MP, 2011), Seshachalam Hills (AP, 2011).\n12 UNESCO MAB; Panna added 2020, Khangchendzonga 2018." }
            ]
          },
          {
            "label": "Ramsar Sites",
            "children": [
              { "label": "80+ sites (2024), highest in South Asia.\nMaximum in Tamil Nadu, then UP." },
              { "label": "Recent additions (2024): Ankasamudra, Aghanashini (Karnataka); Karaivetti, Longwood Shola (TN); Magadi Kere (Karnataka)." },
              { "label": "Montreux Record: Keoladeo NP, Loktak Lake.\nChilika removed 2002." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Climate Change & Disasters",
        "children": [
          {
            "label": "Global Agreements & Targets",
            "children": [
              { "label": "Kyoto Protocol (1997): Binding emission cuts for Annex-I countries." },
              { "label": "Paris Agreement (2015): Limit warming well below 2°C, pursue 1.5°C.\nNDCs every 5 years." },
              { "label": "India's Panchamrit (COP26): 500 GW non-fossil capacity by 2030, net-zero by 2070." },
              { "label": "ISA & CDRI: India-initiated global partnerships." }
            ]
          },
          {
            "label": "Disasters & Vulnerability",
            "children": [
              { "label": "Himalayas (Zone IV/V earthquakes, landslides); East Coast (cyclones); Indo-Gangetic plain & Assam (floods); Peninsular interior (drought – Marathwada, Vidarbha, Bundelkhand)." }
            ]
          },
          {
            "label": "Grassroots Environmental Movements",
            "children": [
              { "label": "Chipko (Garhwal, Sunderlal Bahuguna); Appiko (Karnataka); Silent Valley Movement (Kerala); Narmada Bachao Andolan (Medha Patkar)." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Important Maps & Location-based Facts",
        "children": [
          {
            "label": "Borders & Neighbours",
            "children": [
              { "label": "Land Borders (Longest to Shortest): Bangladesh (4096 km) > China > Pakistan > Nepal > Myanmar > Bhutan > Afghanistan (106 km via PoK)." },
              { "label": "Neighbor Capitals: Dhaka, Kathmandu, Colombo/Sri Jayawardenepura Kotte, Islamabad, Thimphu, Naypyidaw." },
              { "label": "States bordering Myanmar: Arunachal, Nagaland, Manipur, Mizoram (ARUNa-MAMi)." }
            ]
          },
          {
            "label": "Important Latitudes & Longitudes",
            "children": [
              { "label": "Tropic of Cancer (23.5°N): Passes through 8 states – Gujarat, Rajasthan, MP, Chhattisgarh, Jharkhand, WB, Tripura, Mizoram." },
              { "label": "Indian Standard Meridian (82.5°E): Passes through Mirzapur (UP).\nIntersects Tropic of Cancer in Chhattisgarh.\nStates: UP, MP, Chhattisgarh, Odisha, AP." },
              { "label": "Latitudinal & Longitudinal Extent: 8°4'N – 37°6'N, 68°7'E – 97°25'E.\n~30° span causes 2-hour time difference." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER X ===========================
  {
    "id": "X",
    "p": "pm2",
    "label": "Settlement Geography & Regional Planning (Mains Focus)",
    "children": [
      {
        "p": "pm2",
        "label": "Urban Settlements & Hierarchy",
        "children": [
          {
            "label": "Christaller's Central Place Theory (1933)",
            "children": [
              { "label": "Hexagonal pattern.\nRange (max distance) and Threshold (min market size)." },
              { "label": "Three principles: Marketing (K=3), Transport (K=4), Administrative (K=7)." }
            ]
          },
          {
            "label": "Rank-Size Rule & Primate City",
            "children": [
              { "label": "Rank-Size Rule: Pn = P1 / n.\nObserved in developed countries." },
              { "label": "Primate City: One dominant city many times larger than next (Bangkok, Paris).\nIndia lacks a true primate city." }
            ]
          },
          {
            "label": "Rural-Urban Fringe",
            "children": [
              { "label": "Transition zone; mixed land use, commuting belt.\nIssues: unplanned growth, loss of farmland, infrastructure strain." }
            ]
          }
        ]
      },
      {
        "p": "pm2",
        "label": "Regional Development & Planning",
        "children": [
          {
            "label": "Concept of Region",
            "children": [
              { "label": "Formal (uniform characteristic), Functional (interactions/nodal), Planning (unit for coordinated development)." }
            ]
          },
          {
            "label": "Regional Disparities in India",
            "children": [
              { "label": "Inter-state and intra-state disparities in income, infrastructure, health.\nBIMARU states historically lagging." },
              { "label": "Causes: historical legacy, resource endowment, policy decisions, investment concentration." },
              { "label": "Remedies: Backward region grants, Special Category Status, Aspirational Districts Programme (NITI Aayog), infrastructure push." }
            ]
          },
          {
            "label": "Special Area Development",
            "children": [
              { "label": "Hill Area Development, Desert Development, Tribal Sub-Plan, Border Area Development.\nFocus on local needs, ecology, inclusive growth." }
            ]
          }
        ]
      }
    ]
  },
  // =========================== CHAPTER XI ===========================
  {
    "id": "XI",
    "p": "pm1",
    "label": "Geographical Thought & Techniques (Mains Oriented)",
    "children": [
      {
        "p": "pm1",
        "label": "Evolution of Geographical Thought",
        "children": [
          {
            "label": "Ancient & Classical",
            "children": [
              { "label": "Greeks: Eratosthenes coined 'Geography', calculated Earth's circumference.\nPtolemy's Geographia.\nRomans: Strabo's regional geography." }
            ]
          },
          {
            "label": "Modern Paradigms",
            "children": [
              { "label": "Determinism: Ratzel, Ellen Semple – environment controls man.\nPossibilism: Vidal de la Blache, Febvre – environment offers possibilities, man chooses.\nNeo-determinism (stop-and-go determinism): Griffith Taylor." },
              { "label": "Quantitative Revolution (1950s-60s): spatial analysis, models, logical positivism.\nFollowed by behavioural, humanistic, radical approaches." }
            ]
          }
        ]
      },
      {
        "p": "pm1",
        "label": "Remote Sensing & GIS",
        "children": [
          {
            "label": "Remote Sensing",
            "children": [
              { "label": "Passive (optical, thermal) vs Active (Radar, Lidar).\nPlatforms: Ground, airborne, spaceborne." },
              { "label": "Indian satellites: IRS series, Cartosat, Resourcesat, RISAT.\nStages in RS: Energy source, interaction with atmosphere & target, sensor recording, processing, interpretation." }
            ]
          },
          {
            "label": "GIS & GNSS",
            "children": [
              { "label": "GIS: Hardware, software, data, people, methods.\nSpatial data: raster vs vector.\nApplications in urban planning, disaster management, resource mapping." },
              { "label": "GNSS: GPS (USA), GLONASS (Russia), Galileo (EU), BeiDou (China), NavIC (India's regional)." }
            ]
          }
        ]
      }
    ]
  }
] satisfies RawSubjectNode[];