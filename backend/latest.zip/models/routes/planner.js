const express = require("express");
const router = express.Router();
const WeeklyPlan = require("../WeeklyPlan");

const {
  createEvent,
  deleteEvent,
} = require("../../services/googleCalendarService");

// GET PLANNER DAYS FOR A YEAR
router.get("/year/:year", async (req, res) => {
  try {
    const selectedYear = Number(req.params.year);

    if (!Number.isInteger(selectedYear) || selectedYear < 1970 || selectedYear > 3000) {
      return res.status(400).json({ error: "Invalid planner year." });
    }

    const yearStart = `${selectedYear}-01-01`;
    const yearEnd = `${selectedYear}-12-31`;
    const plans = await WeeklyPlan.find({
      "days.dateKey": { $gte: yearStart, $lte: yearEnd },
    }).lean();

    const days = plans
      .flatMap((plan) => plan.days || [])
      .filter((day) => day.dateKey >= yearStart && day.dateKey <= yearEnd)
      .sort((first, second) => first.dateKey.localeCompare(second.dateKey));

    return res.json({
      ok: true,
      data: days,
    });
  } catch (err) {
    console.error("GET PLANNER YEAR ERROR:", err);
    return res.status(500).json({ error: "Failed to fetch planner year." });
  }
});

// GET WEEKLY PLAN
router.get("/:weekStart", async (req, res) => {
  try {
    const { weekStart } = req.params;

    const plan = await WeeklyPlan.findOne({
      weekStartDate: weekStart,
    }).lean();

    if (!plan) {
      return res.json({
        exists: false,
        data: null,
      });
    }

    return res.json({
      exists: true,
      data: plan,
    });
  } catch (err) {
    console.error("GET PLANNER ERROR:", err);
    return res.status(500).json({ error: "Failed to fetch weekly plan." });
  }
});

// SAVE/UPDATE WEEKLY PLAN
router.post("/", async (req, res) => {
  try {
    const {
      weekStartDate,
      status = "Draft",
      committedAt = null,
      revisionsCount = 0,
      executionMatrix = {},
      days = [],
      updatedAt: clientTimestamp, // ✅ Capture exactly what the client sent (if anything)
    } = req.body || {};

    if (!weekStartDate) {
      return res.status(400).json({ error: "weekStartDate is required." });
    }

    // 🛡️ PRO FIX: Timestamp Conflict Resolution Engine
    const existingPlan = await WeeklyPlan.findOne({ weekStartDate }).lean();

    // Only compare if the client actually provided a timestamp
    if (existingPlan && existingPlan.updatedAt && clientTimestamp) {
      if (clientTimestamp < existingPlan.updatedAt) {
        console.warn(
          "⚠️ Sync Rejected: Database has a newer version. Preventing cross-device overwrite.",
        );
        return res.status(409).json({
          error: "Conflict: Newer version exists in database.",
          data: existingPlan,
        });
      }
    }

    // Generate the true server timestamp ONLY at the moment of saving
    // =======================================
    // DELETE REMOVED GOOGLE CALENDAR EVENTS
    // =======================================

    if (existingPlan) {
      // Collect all mission IDs that still exist in the incoming request
      const incomingMissionIds = new Set();

      for (const day of days) {
        for (const mission of day.noteMissions || []) {
          incomingMissionIds.add(mission.id);
        }
      }

      // Find missions that existed previously but are now gone
      for (const oldDay of existingPlan.days || []) {
        for (const oldMission of oldDay.noteMissions || []) {
          if (!incomingMissionIds.has(oldMission.id)) {
            if (oldMission.googleCalendarEventId) {
              try {
                await deleteEvent(oldMission.googleCalendarEventId);

                console.log(
                  `🗑 Deleted Google Calendar event: ${oldMission.googleCalendarEventId}`,
                );
              } catch (err) {
                console.error(
                  "Failed to delete Google Calendar event:",
                  err.message,
                );
              }
            }
          }
        }
      }
    }

    // Generate the true server timestamp ONLY at the moment of saving
    const serverTimestamp = Date.now();

    // =======================================
    // GOOGLE CALENDAR SYNC
    // =======================================

    for (const day of days) {
      if (!day.noteMissions) continue;

      for (const mission of day.noteMissions) {
        if (mission.googleCalendarEventId) continue;

        const start = mission.timeValidation?.plannedStart;
        const end = mission.timeValidation?.plannedEnd;

        if (!start || !end) continue;

        const startDate = new Date(`${day.dateKey}T${start}:00+05:30`);
        const endDate = new Date(`${day.dateKey}T${end}:00+05:30`);

        const event = await createEvent({
          summary: `${mission.subject} • ${mission.chapterLabel}`,

          description: (() => {
            const totalTopics = mission.targets.length;

            const completedTopics = mission.targets.filter(
              (t) => t.isCompleted,
            ).length;

            const revisedTopics = mission.targets.filter(
              (t) => t.isRevised,
            ).length;

            const totalPoints = mission.targets.reduce(
              (sum, t) => sum + (t.leafUids?.length || 0),
              0,
            );

            const completedPoints = mission.targets.reduce((sum, t) => {
              if (t.isCompleted) {
                return sum + (t.leafUids?.length || 0);
              }
              return sum;
            }, 0);

            const remainingPoints = totalPoints - completedPoints;

            const targetList = mission.targets
              .map((t) => {
                const status = t.isRevised
                  ? "🔄 Revised"
                  : t.isCompleted
                    ? "✅ Completed"
                    : "⏳ Pending";

                return [
                  `${t.label}`,
                  `   • Points : ${t.leafUids?.length || 0}`,
                  `   • Status : ${status}`,
                ].join("\n");
              })
              .join("\n\n");

            return `
🎯 UPSC Study Mission

📖 Subject
${mission.subject}

🏛 Chapter
${mission.chapterLabel}

━━━━━━━━━━━━━━━━━━━━━━

📚 Targets

${targetList}

━━━━━━━━━━━━━━━━━━━━━━

📊 Mission Stats

Topics : ${totalTopics}

Points : ${totalPoints}

Completed Topics : ${completedTopics}

Revised Topics : ${revisedTopics}

Completed Points : ${completedPoints}

Remaining Points : ${remainingPoints}

━━━━━━━━━━━━━━━━━━━━━━

🔥 Generated by UPSC Dashboard
`;
          })(),

          start: {
            dateTime: startDate.toISOString(),
            timeZone: "Asia/Kolkata",
          },

          end: {
            dateTime: endDate.toISOString(),
            timeZone: "Asia/Kolkata",
          },

          reminders: {
            useDefault: false,
            overrides: [
              {
                method: "popup",
                minutes: 10,
              },
            ],
          },
        });

        mission.googleCalendarEventId = event.id;
      }
    }

    // =======================================

    const plan = await WeeklyPlan.findOneAndUpdate(
      { weekStartDate },
      {
        weekStartDate,
        status,
        committedAt,
        revisionsCount,
        executionMatrix,
        days,
        updatedAt: serverTimestamp, // ✅ Lock in the definitive new server timestamp
      },
      { upsert: true, new: true, runValidators: true },
    ).lean();

    return res.json({
      ok: true,
      data: plan,
    });
  } catch (err) {
    console.error("POST PLANNER ERROR:", err);
    return res.status(500).json({ error: "Failed to save weekly plan." });
  }
});

module.exports = router;
